# LISPMIND: The Living Orchestrator

> *"Code that heals itself. Agents that outlive their bugs. A system that
> learns while it runs — and never stops running."*

**LISPMIND** is a production-grade, self-healing agent orchestrator written in
Common Lisp (SBCL). It runs as a single, live, malleable image on an air-gapped
Kali Linux system.  Using the full power of CLOS MOP, the condition/restart
system, hot-patching, and macro-driven agent factories, LISPMIND creates a
*colony* of autonomous agents that monitor each other, recover from failure,
and rewrite their own strategies at runtime — **without ever restarting the
process**.

Think of it as a Kubernetes for Lisp — if Kubernetes could rewrite its own
scheduler while it was scheduling.

---

## Features

| Feature | Description |
|---------|-------------|
| **Self-Healing Agents** | Every agent carries a health score, heartbeat, and error budget. The orchestrator detects failure, stalls, and resource exhaustion — then applies the right restart automatically. |
| **Hot-Patching (Zero Downtime)** | Replace an agent's strategy function while it runs.  Old versions are preserved in a version history — rollback any time with `(mind:rollback-strategy agent)`. |
| **CLOS MOP Hooks** | `:around` methods on slot accessors trigger notifications when health or status changes.  The orchestrator reacts instantly — no polling needed. |
| **Macro-Driven Agent Factory** | `define-agent-type` is a full DSL: declare a new agent species with capabilities, strategy, and health thresholds in one expression.  It generates the class, methods, error handling, and restart bindings automatically. |
| **Checkpoint / Restore** | Serialize any agent (or the entire orchestrator) to disk with `cl-store`.  Restore after power loss with zero state loss. |
| **ASCII Dashboard** | Live REPL dashboard showing every agent's health, status, error count, and heartbeat age.  Run it in a dedicated thread and watch your colony breathe. |
| **Condition/Restart Protocol** | Six restart strategies (`:retry`, `:use-fallback`, `:escalate`, `:replace-agent`, `:hotfix-and-continue`, `:pause-and-self-modify`) are selected by a rule-based policy engine. |
| **Genetic Evolution (v2.0)** | Agents evolve their own strategies using tree-based genetic programming. When failure rates cross thresholds, the orchestrator breeds better strategies — zero human intervention required. |
| **ZeroMQ Gossip Mesh (v2.0)** | Distributed pub/sub messaging across machines without a central broker. Agents synchronize state, health, and evolution events across the LAN — the swarm survives even if nodes go dark. |
| **Image-Based Immortality (v2.0)** | `sb-ext:save-lisp-and-die` captures the ENTIRE running image as an executable. After power loss, run the golden image and the swarm resurrects exactly where it left off. |
| **Live FlameGraphs (v2.0)** | `sb-sprof` integration generates real-time ASCII flamegraphs showing CPU hotspots per agent. Auto-tuning detects >80% time functions and optimizes them automatically (inline, type declarations, recompile). |

---

### LISPMIND v2.0 — The Evolution

Version 2.0 transforms LISPMIND from a single-node orchestrator into a **distributed, self-evolving, immortal swarm**:

- **Evolution Engine** (`evolution.lisp`) — Tree-based genetic programming that evolves agent strategies as S-expressions. Agents literally write their own superior code when they hit blockages.
- **Gossip Protocol** (`gossip.lisp`) — ZeroMQ PUB/SUB mesh for agent communication across machines. No broker, no single point of failure.
- **Golden Images** (`image-persist.lisp`) — Cryogenic persistence of the entire Lisp image. Resurrection after hardware death.
- **Profiler + Auto-Tune** (`profiler.lisp`) — Real-time flamegraphs and automatic hotspot optimization.

---

## Prerequisites

- **SBCL** (Steel Bank Common Lisp) — tested on SBCL 2.3.x and later
- **Quicklisp** — the Common Lisp library manager
- A terminal with a monospace font (for the ASCII dashboard)

---

## Air-Gapped Kali Linux Installation

On a Kali Linux machine without internet access, follow these steps:

### 1. Install SBCL

```bash
sudo apt-get update
sudo apt-get install -y sbcl
```

Verify:
```bash
sbcl --version
# SBCL 2.3.x (or later)
```

### 2. Install Quicklisp (Offline Bootstrap)

On an internet-connected machine, download the Quicklisp bootstrap:
```bash
curl -O https://beta.quicklisp.org/quicklisp.lisp
```

Transfer `quicklisp.lisp` to the air-gapped Kali machine (USB, SCP, etc.),
then:

```bash
sbcl --load quicklisp.lisp
```

Inside the SBCL REPL:
```lisp
(quicklisp-quickstart:install)
(ql:add-to-init-file)
(quit)
```

### 3. Obtain & Place LISPMIND

Transfer the LISPMIND project directory to the air-gapped machine:

```bash
mkdir -p ~/quicklisp/local-projects/
cp -r /path/to/lispmind ~/quicklisp/local-projects/lispmind/
```

The directory layout should look like:
```
~/quicklisp/local-projects/lispmind/
  ├── lispmind.asd         # ASDF system definition
  ├── packages.lisp        # Package exports (263+ symbols)
  ├── conditions.lisp      # Custom conditions + 6 restarts
  ├── agent-class.lisp     # Agent base class with MOP hooks
  ├── macros.lisp          # define-agent-type macro factory
  ├── orchestrator.lisp    # Registry, monitor loop, healing
  ├── hotpatch.lisp        # Zero-downtime strategy replacement
  ├── checkpoint.lisp      # cl-store state persistence
  ├── gossip.lisp          # [v2.0] ZeroMQ distributed mesh
  ├── evolution.lisp       # [v2.0] Genetic programming engine
  ├── image-persist.lisp   # [v2.0] Golden image resurrection
  ├── profiler.lisp        # [v2.0] FlameGraph + auto-tuning
  ├── dashboard.lisp       # REPL dashboard (v1 + v2 panels)
  ├── demo.lisp            # Epic 7-act demonstration
  └── README.md            # This file
```

### 4. Resolve Dependencies

You need the following libraries available to Quicklisp.  On an air-gapped
system, download them (and their transitive dependencies) on a connected
machine:

```bash
# On an internet-connected machine with SBCL + Quicklisp:
sbcl --eval '(ql:quickload "bordeaux-threads")' \
     --eval '(ql:quickload "closer-mop")' \
     --eval '(ql:quickload "alexandria")' \
     --eval '(ql:quickload "cl-ppcre")' \
     --eval '(ql:quickload "local-time")' \
     --eval '(ql:quickload "cl-store")' \
     --eval '(ql:quickload "lparallel")' \
     --eval '(quit)'
```

**Optional (for v2.0 distributed mode):**
```bash
sbcl --eval '(ql:quickload "cl-zeromq")' --eval '(quit)'
```

Then copy `~/quicklisp/dists/` and `~/quicklisp/quicklisp/` to the same
paths on the air-gapped machine.

### 5. Load LISPMIND

```bash
sbcl
```

```lisp
(ql:quickload :lispmind)
```

If all dependencies are satisfied, you will see compilation output for all
ten Lisp files followed by `:LISPMIND` — the system is alive.

---

## Quickstart

```lisp
;; Load the system
(ql:quickload :lispmind)

;; Run the self-contained demonstration
(mind:run-demo)
```

You will see:
1. An orchestrator booting up
2. Five agents spawning (3 web-scrapers, 2 analysts)
3. A simulated network failure being injected
4. The orchestrator healing the agent automatically
5. A hot-patch upgrading a broken strategy
6. Live dashboard updates for 6 seconds
7. Clean shutdown with a final summary

---

## REPL God-Mode Commands

| Command | What It Does |
|---------|-------------|
| `(mind:run-demo)` | Run the full self-healing demonstration |
| `(mind:start-orchestrator)` | Create and launch a new orchestrator |
| `(mind:stop-orchestrator orch)` | Gracefully shut down an orchestrator |
| `(mind:list-agents)` | List every registered agent with status |
| `(mind:inspect-agent 'agent-id)` | Deep inspection of a single agent |
| `(mind:heal-agent orch 'id :retry)` | Apply `:retry` restart to an agent |
| `(mind:hotpatch-agent agent :new-strategy #'my-fn)` | Replace strategy at runtime |
| `(mind:rollback-strategy agent 1)` | Roll back 1 strategy version |
| `(mind:checkpoint-system orch "./checkpoints/")` | Save all state to disk |
| `(mind:restore-system orch "./checkpoints/")` | Restore all agents from disk |
| `(mind:start-dashboard orch)` | Launch the live ASCII dashboard |
| `(mind:stop-dashboard)` | Kill the dashboard thread |
| `(mind:simulate-failure 'id 'agent-failure)` | Inject a synthetic failure |
| `(mind:send-message orch 'from 'to "hello")` | Send an inter-agent message |
| `(mind:define-agent-type my-agent ...)` | Declare a new agent species |

### v2.0 Swarm Commands

| Command | What It Does |
|---------|-------------|
| `(mind:start-dashboard-v2)` | Launch v2 dashboard with flamegraph + gossip + evolution |
| `(mind:define-evolving-agent scraper :capabilities '(fetch parse))` | Create an agent that evolves its own strategy |
| `(mind:start-gossip-node :peers '("tcp://192.168.1.2:55555"))` | Join a distributed gossip mesh |
| `(mind:publish-message "swarm.health" '((scraper-1 . 100)))` | Broadcast to the swarm |
| `(mind:save-golden-image orch :reason "major-improvement")` | Save entire image as executable |
| `(mind:enable-immortality orch)` | Auto-save + watchdog + auto-resurrection |
| `(mind:start-swarm-profile)` | Start real-time CPU profiling |
| `(mind:generate-flamegraph)` | Print ASCII flamegraph of hotspots |
| `(mind:auto-tune-hotspot 'my-slow-function)` | Optimize a hotspot automatically |
| `(mind:evolution-history 'scraper-1)` | Show genetic lineage of an agent |

### Pro Tips

```lisp
;; Create a web-scraper agent inline
(defvar *scraper* (mind:make-agent :capabilities '(fetch parse store)))

;; Start a dashboard that refreshes every 2 seconds
(mind:start-dashboard)

;; Inject chaos and watch the system heal
(mind:simulate-failure 'scraper-1 'external-timeout)

;; Save everything before you go
(mind:checkpoint-system *orchestrator* "/tmp/lispmind-backup/")

;; v2.0 — Create an evolving agent and watch it improve itself
(mind:define-evolving-agent web-scraper :capabilities '(fetch parse store))
(mind:start-dashboard-v2)  ; Watch flamegraph + gossip + evolution live

;; v2.0 — Go immortal (auto-save golden images + watchdog)
(mind:enable-immortality *orchestrator*)

;; v2.0 — Start a distributed swarm across two machines
(mind:start-gossip-node :peers '("tcp://192.168.1.101:55555"))
```

---

## Architecture Overview

```
  ┌──────────────────────────────────────────────────────────────────────┐
  │                    LISPMIND v2.0 — THE IMMORTAL SWARM                 │
  │                                                                        │
  │  ┌──────────────────────────────────────────────────────────────┐     │
  │  │            MONITOR LOOP v2 (bordeaux-threads)                  │     │
  │  │  Every 2s:  check heartbeats ──> heal if dead/stalled        │     │
  │  │             handler-bind ──> 7 restart strategies (+:evolve)  │     │
  │  │             profiler-check ──> auto-tune hotspots             │     │
  │  │             evolution-check ──> GP strategy breeding          │     │
  │  │             gossip-publish ──> swarm state broadcast          │     │
  │  │             golden-check ──> save image on improvement        │     │
  │  └──────────────────────────────────────────────────────────────┘     │
  │                         │                                              │
  │         ┌───────────────┼───────────────┐                              │
  │         ▼               ▼               ▼                              │
  │  ┌──────────┐   ┌──────────┐   ┌──────────┐  ┌──────────┐           │
  │  │  Agent 1 │   │  Agent 2 │   │  Agent N │  │ [Remote] │  ...      │
  │  │:evolving │   │ :healing │   │ :paused  │  │  (ZMQ)   │           │
  │  │ health=92│   │ health=60│   │ health=100│  │health=85 │           │
  │  │ gen=7    │   │ errors=4 │   │ errors=0 │  │ errors=1 │           │
  │  └────┬─────┘   └────┬─────┘   └────┬─────┘  └────┬─────┘           │
  │       │              │              │              │                  │
  │       └──────────────┼──────────────┘              │                  │
  │                      ▼                            ▼                  │
  │         ┌──────────────────────┐      ┌─────────────────────┐         │
  │         │  MOP :around hooks   │      │   GOSSIP (ZeroMQ)    │         │
  │         │  health/status notify│      │   pub/sub mesh       │         │
  │         └──────────────────────┘      │   cross-machine      │         │
  │                      │                └─────────────────────┘         │
  │         ┌────────────┼────────────┐                                   │
  │         ▼            ▼            ▼                                   │
  │  ┌──────────┐ ┌──────────┐ ┌──────────────┐                          │
  │  │ HOTPATCH │ │CHECKPOINT│ │    GOLDEN    │                          │
  │  │ Versioned│ │ cl-store │ │   IMAGE      │                          │
  │  │strategies│ │serialize │ │ save-lisp-   │                          │
  │  └──────────┘ └──────────┘ └──────────────┘                          │
  │                                            ┌──────────────┐          │
  │  ┌──────────┐ ┌──────────┐ ┌──────────┐  │  EVOLUTION   │          │
  │  │ DASHBOARD│ │ PROFILER │ │ FLAMEGR. │  │    (GP)      │          │
  │  │  ASCII   │ │sb-sprof  │ │  ASCII   │  │ S-expression │          │
  │  │  v2.0    │ │ auto-tune│ │  bars    │  │   trees      │          │
  │  └──────────┘ └──────────┘ └──────────┘  └──────────────┘          │
  └──────────────────────────────────────────────────────────────────────┘

  DEFINE-EVOLVING-AGENT Macro (v2.0)
  ├─> define-agent-type (inherits from AGENT)
  ├─> strategy-chromosome (S-expression tree)
  ├─> evolve-strategy on failure (GP: mutate + crossover + select)
  └─> hotpatch evolved strategy into running agent (zero downtime)
```

### File Dependency Graph

```
  packages ──> conditions ──> agent-class ──> macros ──> orchestrator
                                                              │
                          ┌───────────────────────────────────┼───┐
                          ▼                                   ▼   ▼
  hotpatch ──> checkpoint    gossip ──> evolution ──> image-persist
                                                              │
                          ┌───────────────────────────────────┘
                          ▼
                    profiler ──> dashboard ──> demo

  v1.0 core ──────────────────────────────────────────────>│
  v2.0 extensions ─────────────────────────────────────────>│
```

---

## The Philosophy

LISPMIND is built on a radical premise: **a running Lisp image is not a static
artifact — it is a living system**.  Functions are not binaries to deploy;
they are organisms to evolve.  Agents are not processes to restart; they are
cells that regenerate.  The orchestrator is not a supervisor; it is an
immune system.

When a web scraper hits a network timeout, LISPMIND doesn't crash.  It retries.
If that fails, it falls back.  If errors accumulate, it hot-patches new logic
into the running agent.  If all else fails, it replaces the agent with a fresh
clone — carrying over its state, but not its bugs.

All of this happens while the rest of the colony keeps running.  **Zero
downtime. Zero restarts. Pure living code.**

---

## Extend It

LISPMIND v2.0 is a distributed, self-evolving swarm — but there's always room
for more:

- **Add a new agent type**: `(mind:define-agent-type crypto-trader ...)` or `(mind:define-evolving-agent crypto-trader ...)`
- **Add a new restart**: Extend `default-restart-policy` — or add `:evolve` for GP healing
- **Add a new condition**: Inherit from `agent-failure` in conditions.lisp
- **Expand the gossip mesh**: Add peers at runtime — the swarm auto-discovers
- **Tune the GP engine**: Adjust `*mutation-rate*`, `*crossover-rate*`, tournament size
- **Custom flamegraph colors**: Modify `flamegraph-color` in profiler.lisp
- **Golden image rotation**: Change `*golden-image-count*` for longer/shorter history
- **Neural GP hybrids**: Replace the fitness function with a neural critic
- **Web dashboard**: Replace ASCII with a React frontend over WebSockets

The MOP hooks are there. The restart protocol is there. The macro factory
is there. The genetic programming engine is there. **What will you build?**

---

*Hack the planet. Heal the code. Evolve the swarm. Long live Lisp.*

---

**LISPMIND v2.0 — The Immortal Swarm**
*13,855 lines of living Common Lisp. Zero downtime. Infinite evolution.*
